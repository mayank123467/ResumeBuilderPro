package com.resumebuilder.pro.ai

import com.google.gson.Gson
import com.google.gson.JsonObject
import com.resumebuilder.pro.model.GrammarIssue
import com.resumebuilder.pro.model.ResumeData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

object AiResumeAssistant {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()
    private val gson = Gson()

    fun checkGrammarAndStyle(data: ResumeData): List<GrammarIssue> {
        val issues = mutableListOf<GrammarIssue>()
        val weakPhrases = mapOf(
            "responsible for" to "Replace with strong action verb (e.g., 'Led', 'Managed', 'Executed').",
            "worked on" to "Replace with 'Engineered', 'Developed', or 'Implemented'.",
            "helped with" to "Replace with 'Collaborated on' or 'Supported'.",
            "duties included" to "Focus on achievements instead of 'duties included'.",
            "i am" to "Avoid first-person pronouns ('I', 'my') in resumes.",
            "my name is" to "Remove 'my name is' — start directly with your role and strengths."
        )

        val summaryLower = data.summary.lowercase()
        weakPhrases.forEach { (weak, fix) ->
            if (summaryLower.contains(weak)) {
                issues.add(GrammarIssue("Summary", "Weak/informal phrase: \"$weak\"", fix))
            }
        }
        if (data.summary.isNotBlank() && data.summary.first().isLowerCase()) {
            issues.add(GrammarIssue("Summary", "Starts with a lowercase letter", "Capitalize the first word of your summary."))
        }
        if (data.summary.contains("  ")) {
            issues.add(GrammarIssue("Summary", "Extra double spaces detected", "Clean up extra whitespace."))
        }

        data.experiences.forEachIndexed { idx, exp ->
            val bLower = exp.bullets.lowercase()
            weakPhrases.forEach { (weak, fix) ->
                if (bLower.contains(weak)) {
                    issues.add(GrammarIssue("Experience #${idx + 1}", "Weak phrase: \"$weak\"", fix))
                }
            }
            if (exp.bullets.isNotBlank() && !Regex("\\d+").containsMatchIn(exp.bullets)) {
                issues.add(GrammarIssue("Experience #${idx + 1}", "No measurable numbers or % found", "Add metrics like 'by 20%' or '10+ projects' for higher ATS score."))
            }
        }
        return issues
    }

    fun autoFixText(text: String): String {
        if (text.isBlank()) return text
        var fixed = text.replace(Regex(" {2,}"), " ").trim()
        val replacements = listOf(
            Regex("\\bresponsible for\\b", RegexOption.IGNORE_CASE) to "Managed and executed",
            Regex("\\bworked on\\b", RegexOption.IGNORE_CASE) to "Developed and delivered",
            Regex("\\bhelped with\\b", RegexOption.IGNORE_CASE) to "Collaborated on",
            Regex("\\bduties included\\b", RegexOption.IGNORE_CASE) to "Key achievements included",
            Regex("\\bi am a\\b", RegexOption.IGNORE_CASE) to "Results-driven",
            Regex("\\bi am\\b", RegexOption.IGNORE_CASE) to "Experienced"
        )
        for ((pattern, repl) in replacements) {
            fixed = pattern.replace(fixed, repl)
        }
        fixed = fixed.lines().joinToString("\n") { line ->
            val trimmed = line.trim()
            if (trimmed.isEmpty()) ""
            else trimmed.replaceFirstChar { it.uppercase() }
        }
        return fixed
    }

    suspend fun generateSummary(jobTitle: String, skills: String, apiKey: String): String {
        val role = jobTitle.ifBlank { "Professional" }
        val skillText = skills.ifBlank { "problem solving, team leadership, and process optimization" }
        if (apiKey.isNotBlank()) {
            val prompt = "Write a concise, 3-line ATS-friendly resume professional summary (no first-person pronouns like I/my) for a $role with skills: $skillText."
            val aiResp = callGemini(prompt, apiKey)
            if (!aiResp.isNullOrBlank()) return aiResp.trim()
        }
        return "Results-driven $role with a strong track record in $skillText. Proven ability to streamline workflows, deliver measurable quality improvements, and collaborate cross-functionally to achieve business goals."
    }

    suspend fun upgradeBullets(role: String, rawBullets: String, apiKey: String): String {
        val targetRole = role.ifBlank { "Team Lead" }
        if (apiKey.isNotBlank() && rawBullets.isNotBlank()) {
            val prompt = "Rewrite these resume bullet points for a $targetRole using strong action verbs, clear grammar, and ATS-friendly phrasing. Return only 3-4 concise bullet lines starting with •:\n$rawBullets"
            val aiResp = callGemini(prompt, apiKey)
            if (!aiResp.isNullOrBlank()) return aiResp.trim()
        }
        val cleaned = autoFixText(rawBullets)
        if (cleaned.isBlank()) {
            return "• Spearheaded core $targetRole initiatives, improving team efficiency by 20%\n• Streamlined daily operations and digitized quality checks for zero-defect delivery\n• Collaborated across departments to meet project milestones ahead of schedule"
        }
        return cleaned.lines().filter { it.isNotBlank() }.joinToString("\n") { line ->
            val stripped = line.removePrefix("•").removePrefix("-").trim()
            "• ${stripped.replaceFirstChar { it.uppercase() }}"
        }
    }

    fun suggestSkills(jobTitle: String): String {
        val t = jobTitle.lowercase()
        return when {
            t.contains("engineer") || t.contains("mech") || t.contains("manuf") ->
                "Kaizen, 5S, Total Productive Maintenance (TPM), CNC & VMC Operations, Quality Assurance, Lean Manufacturing, Root Cause Analysis, AutoCAD"
            t.contains("develop") || t.contains("software") || t.contains("it") || t.contains("android") ->
                "Kotlin, Java, Jetpack Compose, REST APIs, Git, Agile/Scrum, SQL, Cloud Architecture, Unit Testing"
            t.contains("sales") || t.contains("market") ->
                "B2B Sales, CRM (Salesforce/HubSpot), Lead Generation, Digital Marketing, SEO/SEM, Client Retention, Negotiation, Revenue Growth"
            t.contains("account") || t.contains("financ") ->
                "Financial Modeling, Tally/SAP, GST & Taxation, Budgeting, Auditing, Excel & Power BI, Risk Analysis"
            else ->
                "Project Management, Process Optimization, Cross-Functional Leadership, Data Analysis, Communication, Strategic Planning, Problem Solving"
        }
    }

    private suspend fun callGemini(prompt: String, apiKey: String): String? = withContext(Dispatchers.IO) {
        try {
            val bodyObj = mapOf(
                "contents" to listOf(
                    mapOf("parts" to listOf(mapOf("text" to prompt)))
                )
            )
            val reqBody = gson.toJson(bodyObj).toRequestBody("application/json; charset=utf-8".toMediaType())
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$apiKey")
                .post(reqBody)
                .build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@withContext null
                val json = gson.fromJson(resp.body?.string(), JsonObject::class.java)
                json?.getAsJsonArray("candidates")
                    ?.firstOrNull()?.asJsonObject
                    ?.getAsJsonObject("content")
                    ?.getAsJsonArray("parts")
                    ?.firstOrNull()?.asJsonObject
                    ?.get("text")?.asString
            }
        } catch (_: Exception) {
            null
        }
    }
}
