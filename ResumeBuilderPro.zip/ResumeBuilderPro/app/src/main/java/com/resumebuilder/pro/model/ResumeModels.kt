package com.resumebuilder.pro.model

enum class ProfessionCategory(val label: String) {
    ALL("All (54)"),
    TECH("Tech & IT"),
    ENGINEERING("Engineering"),
    BUSINESS("Business & Finance"),
    CREATIVE("Creative & Design"),
    HEALTHCARE("Healthcare"),
    SALES("Sales & Marketing"),
    FRESHER("Freshers & Students"),
    EXECUTIVE("Executive & Legal")
}

enum class TemplateLayout {
    CLEAN_CLASSIC,
    MODERN_ACCENT_BAR,
    EXECUTIVE_BANNER,
    MINIMAL_DIVIDER,
    TECH_GRID_HEADER,
    BOLD_SIDE_STRIPE
}

data class ResumeTemplateSpec(
    val id: String,
    val name: String,
    val category: ProfessionCategory,
    val layout: TemplateLayout,
    val accentHex: Long,
    val secondaryHex: Long,
    val useSerif: Boolean = false
)

object TemplateCatalog {
    val all: List<ResumeTemplateSpec> = listOf(
        // Tech & IT (7)
        ResumeTemplateSpec("t1", "Silicon Minimal", ProfessionCategory.TECH, TemplateLayout.TECH_GRID_HEADER, 0xFF1E3A8A, 0xFFDBEAFE),
        ResumeTemplateSpec("t2", "Cloud Architect", ProfessionCategory.TECH, TemplateLayout.MODERN_ACCENT_BAR, 0xFF0284C7, 0xFFE0F2FE),
        ResumeTemplateSpec("t3", "DevOps Clean", ProfessionCategory.TECH, TemplateLayout.MINIMAL_DIVIDER, 0xFF0F172A, 0xFFE2E8F0),
        ResumeTemplateSpec("t4", "AI Engineer Pro", ProfessionCategory.TECH, TemplateLayout.BOLD_SIDE_STRIPE, 0xFF4F46E5, 0xFFE0E7FF),
        ResumeTemplateSpec("t5", "FullStack Slate", ProfessionCategory.TECH, TemplateLayout.CLEAN_CLASSIC, 0xFF1D4ED8, 0xFFDBEAFE),
        ResumeTemplateSpec("t6", "Cyber Guard", ProfessionCategory.TECH, TemplateLayout.EXECUTIVE_BANNER, 0xFF0F766E, 0xFFCCFBF1),
        ResumeTemplateSpec("t7", "Data Science ATS", ProfessionCategory.TECH, TemplateLayout.TECH_GRID_HEADER, 0xFF0369A1, 0xFFE0F2FE),

        // Engineering (7)
        ResumeTemplateSpec("e1", "Kaizen Precision", ProfessionCategory.ENGINEERING, TemplateLayout.BOLD_SIDE_STRIPE, 0xFF1E40AF, 0xFFDBEAFE),
        ResumeTemplateSpec("e2", "MechPro CAD", ProfessionCategory.ENGINEERING, TemplateLayout.MODERN_ACCENT_BAR, 0xFF334155, 0xFFF1F5F9),
        ResumeTemplateSpec("e3", "Industrial Lead", ProfessionCategory.ENGINEERING, TemplateLayout.EXECUTIVE_BANNER, 0xFF0F766E, 0xFFCCFBF1),
        ResumeTemplateSpec("e4", "Plant Ops Clean", ProfessionCategory.ENGINEERING, TemplateLayout.CLEAN_CLASSIC, 0xFF111827, 0xFFF3F4F6),
        ResumeTemplateSpec("e5", "Civil Blueprint", ProfessionCategory.ENGINEERING, TemplateLayout.TECH_GRID_HEADER, 0xFF0369A1, 0xFFE0F2FE),
        ResumeTemplateSpec("e6", "AutoCAD Modern", ProfessionCategory.ENGINEERING, TemplateLayout.MINIMAL_DIVIDER, 0xFF1F2937, 0xFFE5E7EB),
        ResumeTemplateSpec("e7", "Six Sigma Pro", ProfessionCategory.ENGINEERING, TemplateLayout.BOLD_SIDE_STRIPE, 0xFF047857, 0xFFD1FAE5),

        // Business & Finance (7)
        ResumeTemplateSpec("b1", "Wall Street Serif", ProfessionCategory.BUSINESS, TemplateLayout.CLEAN_CLASSIC, 0xFF111827, 0xFFF3F4F6, useSerif = true),
        ResumeTemplateSpec("b2", "FinTech Analyst", ProfessionCategory.BUSINESS, TemplateLayout.MODERN_ACCENT_BAR, 0xFF1E3A8A, 0xFFDBEAFE),
        ResumeTemplateSpec("b3", "Corporate Charter", ProfessionCategory.BUSINESS, TemplateLayout.EXECUTIVE_BANNER, 0xFF1E293B, 0xFFE2E8F0, useSerif = true),
        ResumeTemplateSpec("b4", "Audit & Tax Pro", ProfessionCategory.BUSINESS, TemplateLayout.MINIMAL_DIVIDER, 0xFF065F46, 0xFFD1FAE5),
        ResumeTemplateSpec("b5", "MBA Strategy", ProfessionCategory.BUSINESS, TemplateLayout.BOLD_SIDE_STRIPE, 0xFF312E81, 0xFFE0E7FF),
        ResumeTemplateSpec("b6", "Banking Classic", ProfessionCategory.BUSINESS, TemplateLayout.CLEAN_CLASSIC, 0xFF1E3A8A, 0xFFDBEAFE, useSerif = true),
        ResumeTemplateSpec("b7", "Consulting Edge", ProfessionCategory.BUSINESS, TemplateLayout.TECH_GRID_HEADER, 0xFF0F172A, 0xFFE2E8F0),

        // Creative & Design (7)
        ResumeTemplateSpec("c1", "Studio Modern", ProfessionCategory.CREATIVE, TemplateLayout.BOLD_SIDE_STRIPE, 0xFF7C3AED, 0xFFEDE9FE),
        ResumeTemplateSpec("c2", "UX Portfolio ATS", ProfessionCategory.CREATIVE, TemplateLayout.MODERN_ACCENT_BAR, 0xFFDB2777, 0xFFFCE7F3),
        ResumeTemplateSpec("c3", "Editorial Serif", ProfessionCategory.CREATIVE, TemplateLayout.MINIMAL_DIVIDER, 0xFF9D174D, 0xFFFCE7F3, useSerif = true),
        ResumeTemplateSpec("c4", "Brand Director", ProfessionCategory.CREATIVE, TemplateLayout.EXECUTIVE_BANNER, 0xFF6D28D9, 0xFFEDE9FE),
        ResumeTemplateSpec("c5", "Motion Craft", ProfessionCategory.CREATIVE, TemplateLayout.TECH_GRID_HEADER, 0xFFEA580C, 0xFFFFEDD5),
        ResumeTemplateSpec("c6", "Minimal Canvas", ProfessionCategory.CREATIVE, TemplateLayout.CLEAN_CLASSIC, 0xFF374151, 0xFFF3F4F6),
        ResumeTemplateSpec("c7", "Product Designer", ProfessionCategory.CREATIVE, TemplateLayout.MODERN_ACCENT_BAR, 0xFF0891B2, 0xFFCFFAFE),

        // Healthcare (6)
        ResumeTemplateSpec("h1", "MedCare Clean", ProfessionCategory.HEALTHCARE, TemplateLayout.CLEAN_CLASSIC, 0xFF0F766E, 0xFFCCFBF1),
        ResumeTemplateSpec("h2", "Clinical Pro", ProfessionCategory.HEALTHCARE, TemplateLayout.MODERN_ACCENT_BAR, 0xFF0284C7, 0xFFE0F2FE),
        ResumeTemplateSpec("h3", "Pharma Research", ProfessionCategory.HEALTHCARE, TemplateLayout.EXECUTIVE_BANNER, 0xFF047857, 0xFFD1FAE5),
        ResumeTemplateSpec("h4", "Nursing Care", ProfessionCategory.HEALTHCARE, TemplateLayout.BOLD_SIDE_STRIPE, 0xFF0D9488, 0xFFCCFBF1),
        ResumeTemplateSpec("h5", "Hospital Admin", ProfessionCategory.HEALTHCARE, TemplateLayout.MINIMAL_DIVIDER, 0xFF1E3A8A, 0xFFDBEAFE, useSerif = true),
        ResumeTemplateSpec("h6", "BioTech ATS", ProfessionCategory.HEALTHCARE, TemplateLayout.TECH_GRID_HEADER, 0xFF0369A1, 0xFFE0F2FE),

        // Sales & Marketing (7)
        ResumeTemplateSpec("s1", "Growth Hacker", ProfessionCategory.SALES, TemplateLayout.BOLD_SIDE_STRIPE, 0xFFEA580C, 0xFFFFEDD5),
        ResumeTemplateSpec("s2", "B2B Closer", ProfessionCategory.SALES, TemplateLayout.EXECUTIVE_BANNER, 0xFFB45309, 0xFFFEF3C7),
        ResumeTemplateSpec("s3", "Digital Marketer", ProfessionCategory.SALES, TemplateLayout.MODERN_ACCENT_BAR, 0xFFDC2626, 0xFFFEE2E2),
        ResumeTemplateSpec("s4", "Brand Manager", ProfessionCategory.SALES, TemplateLayout.TECH_GRID_HEADER, 0xFF7C3AED, 0xFFEDE9FE),
        ResumeTemplateSpec("s5", "Retail Lead", ProfessionCategory.SALES, TemplateLayout.CLEAN_CLASSIC, 0xFF1E40AF, 0xFFDBEAFE),
        ResumeTemplateSpec("s6", "SEO Strategist", ProfessionCategory.SALES, TemplateLayout.MINIMAL_DIVIDER, 0xFF0F766E, 0xFFCCFBF1),
        ResumeTemplateSpec("s7", "Revenue Ops", ProfessionCategory.SALES, TemplateLayout.BOLD_SIDE_STRIPE, 0xFF0284C7, 0xFFE0F2FE),

        // Freshers & Students (7)
        ResumeTemplateSpec("f1", "Campus Spark", ProfessionCategory.FRESHER, TemplateLayout.MODERN_ACCENT_BAR, 0xFF2563EB, 0xFFDBEAFE),
        ResumeTemplateSpec("f2", "Graduate Clean", ProfessionCategory.FRESHER, TemplateLayout.CLEAN_CLASSIC, 0xFF111827, 0xFFF3F4F6),
        ResumeTemplateSpec("f3", "Internship Pro", ProfessionCategory.FRESHER, TemplateLayout.BOLD_SIDE_STRIPE, 0xFF059669, 0xFFD1FAE5),
        ResumeTemplateSpec("f4", "Scholar Serif", ProfessionCategory.FRESHER, TemplateLayout.MINIMAL_DIVIDER, 0xFF1E3A8A, 0xFFDBEAFE, useSerif = true),
        ResumeTemplateSpec("f5", "Entry Tech", ProfessionCategory.FRESHER, TemplateLayout.TECH_GRID_HEADER, 0xFF0891B2, 0xFFCFFAFE),
        ResumeTemplateSpec("f6", "First Job ATS", ProfessionCategory.FRESHER, TemplateLayout.EXECUTIVE_BANNER, 0xFF4F46E5, 0xFFE0E7FF),
        ResumeTemplateSpec("f7", "Honors CV", ProfessionCategory.FRESHER, TemplateLayout.CLEAN_CLASSIC, 0xFF374151, 0xFFF3F4F6, useSerif = true),

        // Executive & Legal (6)
        ResumeTemplateSpec("x1", "CXO Executive", ProfessionCategory.EXECUTIVE, TemplateLayout.EXECUTIVE_BANNER, 0xFF0F172A, 0xFFE2E8F0, useSerif = true),
        ResumeTemplateSpec("x2", "Director Slate", ProfessionCategory.EXECUTIVE, TemplateLayout.CLEAN_CLASSIC, 0xFF1E293B, 0xFFF1F5F9, useSerif = true),
        ResumeTemplateSpec("x3", "VP Operations", ProfessionCategory.EXECUTIVE, TemplateLayout.MODERN_ACCENT_BAR, 0xFF1E3A8A, 0xFFDBEAFE),
        ResumeTemplateSpec("x4", "Legal Counsel", ProfessionCategory.EXECUTIVE, TemplateLayout.MINIMAL_DIVIDER, 0xFF111827, 0xFFF3F4F6, useSerif = true),
        ResumeTemplateSpec("x5", "Board Advisor", ProfessionCategory.EXECUTIVE, TemplateLayout.BOLD_SIDE_STRIPE, 0xFF7F1D1D, 0xFFFEE2E2, useSerif = true),
        ResumeTemplateSpec("x6", "Partner Prestige", ProfessionCategory.EXECUTIVE, TemplateLayout.EXECUTIVE_BANNER, 0xFF064E3B, 0xFFD1FAE5, useSerif = true)
    )

    fun byId(id: String): ResumeTemplateSpec = all.firstOrNull { it.id == id } ?: all.first()
}

data class ExperienceItem(
    val id: String = System.currentTimeMillis().toString(),
    val role: String = "",
    val company: String = "",
    val duration: String = "",
    val bullets: String = ""
)

data class EducationItem(
    val id: String = System.currentTimeMillis().toString(),
    val degree: String = "",
    val institution: String = "",
    val year: String = ""
)

data class ResumeData(
    val fullName: String = "",
    val jobTitle: String = "",
    val email: String = "",
    val phone: String = "",
    val location: String = "",
    val linkedin: String = "",
    val summary: String = "",
    val skills: String = "",
    val experiences: List<ExperienceItem> = listOf(ExperienceItem(id = "exp_1")),
    val educations: List<EducationItem> = listOf(EducationItem(id = "edu_1")),
    val templateId: String = "t1",
    val customAccentHex: Long? = null,
    val fontScale: Float = 1.0f,
    val forceSerif: Boolean? = null,
    val compactSpacing: Boolean = false
)

data class AtsReport(
    val score: Int,
    val tips: List<String>
)


data class GrammarIssue(
    val section: String,
    val message: String,
    val suggestion: String
)
