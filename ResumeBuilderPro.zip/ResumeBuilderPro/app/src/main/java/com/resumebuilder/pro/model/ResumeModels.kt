package com.resumebuilder.pro.model

enum class ProfessionCategory(val label: String) {
    ALL("All Professions"),
    TECH("Tech & IT"),
    ENGINEERING("Engineering"),
    BUSINESS("Business & Finance"),
    CREATIVE("Creative & Design"),
    HEALTHCARE("Healthcare"),
    SALES("Sales & Marketing"),
    FRESHER("Freshers & Students"),
    EXECUTIVE("Executive & Legal")
}

enum class TemplateColumnMode(val label: String) {
    ALL("All Layouts"),
    TWO_COLUMN("2-Column Modern"),
    SINGLE_COLUMN("Single-Column ATS"),
    CANVA_MODERN("Canva Style")
}

enum class TemplateLayout(val isTwoColumn: Boolean, val isCanvaStyle: Boolean) {
    CLEAN_CLASSIC(false, false),
    MODERN_ACCENT_BAR(false, true),
    EXECUTIVE_BANNER(false, true),
    MINIMAL_DIVIDER(false, false),
    TWO_COL_SIDEBAR_LEFT(true, true),
    TWO_COL_MODERN_SPLIT(true, true),
    TWO_COL_CANVA_BOLD(true, true),
    TWO_COL_DARK_SIDEBAR(true, true)
}

data class ResumeTemplateSpec(
    val id: String,
    val name: String,
    val category: ProfessionCategory,
    val layout: TemplateLayout,
    val accentHex: Long,
    val secondaryHex: Long,
    val useSerif: Boolean = false
)

object TemplateCatalog {
    private val styleNames = listOf(
        "Canva Sidebar Pro", "Modern Split", "Silicon Minimal", "Executive Banner",
        "Bold Canva Dark", "Classic ATS", "Studio Grid", "Nordic Clean",
        "Coral Modern", "Slate Duo", "Emerald Split", "Indigo Two-Col",
        "Prestige Serif", "Tech Horizon", "Minimalist Line", "Vogue Resume",
        "Summit Pro", "Metro Clean", "Prism Canva", "Aurora Split",
        "Apex Executive", "Vertex Modern", "Craft Studio", "Prime ATS"
    )

    private val palettes = listOf(
        0xFF1E3A8A to 0xFFDBEAFE,
        0xFF0F766E to 0xFFCCFBF1,
        0xFF4F46E5 to 0xFFE0E7FF,
        0xFF0F172A to 0xFFE2E8F0,
        0xFF7C3AED to 0xFFEDE9FE,
        0xFFEA580C to 0xFFFFEDD5,
        0xFF0284C7 to 0xFFE0F2FE,
        0xFF059669 to 0xFFD1FAE5,
        0xFFBE185D to 0xFFFCE7F3,
        0xFF991B1B to 0xFFFEE2E2,
        0xFF334155 to 0xFFF1F5F9,
        0xFFB45309 to 0xFFFEF3C7
    )

    val all: List<ResumeTemplateSpec> by lazy {
        val layouts = TemplateLayout.entries
        val categories = ProfessionCategory.entries.filter { it != ProfessionCategory.ALL }
        buildList {
            categories.forEachIndexed { cIdx, cat ->
                val shortPrefix = cat.label.substringBefore(" ").take(4)
                styleNames.forEachIndexed { sIdx, styleName ->
                    val pal = palettes[(cIdx + sIdx) % palettes.size]
                    val layout = layouts[(cIdx + sIdx) % layouts.size]
                    add(
                        ResumeTemplateSpec(
                            id = "${cat.name.lowercase()}_$sIdx",
                            name = "$shortPrefix $styleName",
                            category = cat,
                            layout = layout,
                            accentHex = pal.first,
                            secondaryHex = pal.second,
                            useSerif = (sIdx % 5 == 0)
                        )
                    )
                }
            }
        }
    }

    fun byId(id: String): ResumeTemplateSpec = all.firstOrNull { it.id == id } ?: all.first()
}

data class ExperienceItem(
    val id: String = System.currentTimeMillis().toString(),
    val role: String = "",
    val company: String = "",
    val duration: String = "",
    val bullets: String = ""
)

data class EducationItem(
    val id: String = System.currentTimeMillis().toString(),
    val degree: String = "",
    val institution: String = "",
    val year: String = ""
)

data class ProjectItem(
    val id: String = System.currentTimeMillis().toString(),
    val title: String = "",
    val techStack: String = "",
    val description: String = ""
)

data class AchievementItem(
    val id: String = System.currentTimeMillis().toString(),
    val title: String = "",
    val year: String = ""
)

data class LanguageItem(
    val id: String = System.currentTimeMillis().toString(),
    val name: String = "",
    val level: String = "Fluent"
)

data class ResumeData(
    val fullName: String = "",
    val jobTitle: String = "",
    val email: String = "",
    val phone: String = "",
    val location: String = "",
    val linkedin: String = "",
    val summary: String = "",
    val skills: String = "",
    val hobbies: String = "",
    val experiences: List<ExperienceItem> = listOf(ExperienceItem(id = "exp_1")),
    val educations: List<EducationItem> = listOf(EducationItem(id = "edu_1")),
    val projects: List<ProjectItem> = listOf(ProjectItem(id = "proj_1")),
    val achievements: List<AchievementItem> = listOf(AchievementItem(id = "ach_1")),
    val languages: List<LanguageItem> = listOf(LanguageItem(id = "lang_1", name = "English", level = "Fluent")),
    val templateId: String = "tech_0",
    val customAccentHex: Long? = null,
    val fontScale: Float = 1.0f,
    val forceSerif: Boolean? = null,
    val compactSpacing: Boolean = false,
    val atsModeEnabled: Boolean = true
)

data class AtsReport(
    val score: Int,
    val tips: List<String>
)

data class GrammarIssue(
    val section: String,
    val message: String,
    val suggestion: String
)
