package com.resumebuilder.pro.model

enum class AtsTemplate(val label: String, val accentHex: Long) {
    CLASSIC_ATS("Classic ATS", 0xFF111827),
    MODERN_BLUE("Modern Blue ATS", 0xFF1E3A8A),
    EXECUTIVE_TEAL("Executive Teal ATS", 0xFF0F766E)
}

data class ExperienceItem(
    val id: String = System.currentTimeMillis().toString(),
    val role: String = "",
    val company: String = "",
    val duration: String = "",
    val bullets: String = ""
)

data class EducationItem(
    val id: String = System.currentTimeMillis().toString(),
    val degree: String = "",
    val institution: String = "",
    val year: String = ""
)

data class ResumeData(
    val fullName: String = "",
    val jobTitle: String = "",
    val email: String = "",
    val phone: String = "",
    val location: String = "",
    val linkedin: String = "",
    val summary: String = "",
    val skills: String = "",
    val experiences: List<ExperienceItem> = listOf(ExperienceItem(id = "exp_1")),
    val educations: List<EducationItem> = listOf(EducationItem(id = "edu_1")),
    val template: AtsTemplate = AtsTemplate.MODERN_BLUE
)

data class AtsReport(
    val score: Int,
    val tips: List<String>
)
