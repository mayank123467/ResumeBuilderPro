package com.resumebuilder.pro.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import com.google.gson.Gson
import com.resumebuilder.pro.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ResumeViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("resume_builder_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    private val _resume = MutableStateFlow(loadSaved())
    val resume: StateFlow<ResumeData> = _resume.asStateFlow()

    private val _ats = MutableStateFlow(computeAts(_resume.value))
    val ats: StateFlow<AtsReport> = _ats.asStateFlow()

    private fun loadSaved(): ResumeData {
        val json = prefs.getString("resume_json", null) ?: return ResumeData()
        return try {
            gson.fromJson(json, ResumeData::class.java) ?: ResumeData()
        } catch (_: Exception) {
            ResumeData()
        }
    }

    fun update(transform: (ResumeData) -> ResumeData) {
        val next = transform(_resume.value)
        _resume.value = next
        _ats.value = computeAts(next)
        prefs.edit().putString("resume_json", gson.toJson(next)).apply()
    }

    fun addExperience() {
        update { it.copy(experiences = it.experiences + ExperienceItem()) }
    }

    fun updateExperience(index: Int, transform: (ExperienceItem) -> ExperienceItem) {
        update { data ->
            val list = data.experiences.toMutableList()
            if (index in list.indices) list[index] = transform(list[index])
            data.copy(experiences = list)
        }
    }

    fun removeExperience(index: Int) {
        update { data ->
            if (data.experiences.size <= 1) data
            else data.copy(experiences = data.experiences.filterIndexed { i, _ -> i != index })
        }
    }

    fun addEducation() {
        update { it.copy(educations = it.educations + EducationItem()) }
    }

    fun updateEducation(index: Int, transform: (EducationItem) -> EducationItem) {
        update { data ->
            val list = data.educations.toMutableList()
            if (index in list.indices) list[index] = transform(list[index])
            data.copy(educations = list)
        }
    }

    fun loadSample() {
        update {
            ResumeData(
                fullName = "Mayank Parekh",
                jobTitle = "Executive Engineer — Manufacturing & Operations",
                email = "mayankparekh567@gmail.com",
                phone = "+91 98765 43210",
                location = "Anand, Gujarat",
                linkedin = "linkedin.com/in/mayankparekh",
                summary = "Results-driven Executive Engineer with expertise in CNC/VMC operations, Kaizen, 5S, and TPM. Proven track record in reducing cycle times and digitizing quality inspection workflows.",
                skills = "Kaizen, 5S, Total Productive Maintenance (TPM), CNC & VMC Operations, MES Dashboards, Process Optimization, Quality Inspection",
                experiences = listOf(
                    ExperienceItem(
                        id = "e1",
                        role = "Executive Engineer (Gear Division)",
                        company = "Elecon Engineering Company Limited",
                        duration = "2018 – Present",
                        bullets = "• Introduced proof machining on hollow shafts prior to deep hole drilling, reducing cycle time by 18%
• Implemented 5S and Kaizen initiatives across shop floor teams to improve safety and OEE
• Digitized First Piece Trial quality checks for error-free dispatch"
                    )
                ),
                educations = listOf(
                    EducationItem(id = "ed1", degree = "B.E. Mechanical Engineering", institution = "Gujarat Technological University", year = "2014")
                ),
                template = AtsTemplate.MODERN_BLUE
            )
        }
    }

    private fun computeAts(d: ResumeData): AtsReport {
        var score = 0
        val tips = mutableListOf<String>()

        if (d.fullName.isNotBlank() && d.email.contains("@") && d.phone.isNotBlank()) score += 20
        else tips.add("Add full name, valid email, and phone number.")

        if (d.summary.length >= 60) score += 15
        else tips.add("Write a 2–3 line Professional Summary (60+ characters).")

        val filledExp = d.experiences.filter { it.role.isNotBlank() && it.company.isNotBlank() }
        if (filledExp.isNotEmpty()) score += 25
        else tips.add("Add at least one Work Experience entry.")

        val hasMetrics = filledExp.any { it.bullets.contains("%") || Regex("\\d+").containsMatchIn(it.bullets) }
        if (hasMetrics) score += 15
        else tips.add("Include numbers or % metrics in your bullet points (e.g., 'reduced cycle time by 18%').")

        val skillCount = d.skills.split(",").map { it.trim() }.count { it.isNotBlank() }
        if (skillCount >= 5) score += 15
        else tips.add("List at least 5 comma-separated Core Skills.")

        if (d.educations.any { it.degree.isNotBlank() }) score += 10
        else tips.add("Add your Education degree and institution.")

        return AtsReport(score.coerceAtMost(100), tips)
    }
}
