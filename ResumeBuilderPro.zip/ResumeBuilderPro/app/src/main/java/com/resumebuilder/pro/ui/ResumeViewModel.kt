package com.resumebuilder.pro.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import com.resumebuilder.pro.BuildConfig
import com.resumebuilder.pro.ai.AiResumeAssistant
import com.resumebuilder.pro.ai.ResumeImporter
import com.resumebuilder.pro.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ResumeViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("resume_builder_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    private val _userEmail = MutableStateFlow(prefs.getString("user_email", null))
    val userEmail: StateFlow<String?> = _userEmail.asStateFlow()

    private val _userName = MutableStateFlow(prefs.getString("user_name", null))
    val userName: StateFlow<String?> = _userName.asStateFlow()

    private val _resume = MutableStateFlow(loadSaved())
    val resume: StateFlow<ResumeData> = _resume.asStateFlow()

    private val _ats = MutableStateFlow(computeAts(_resume.value))
    val ats: StateFlow<AtsReport> = _ats.asStateFlow()

    private val _grammarIssues = MutableStateFlow(AiResumeAssistant.checkGrammarAndStyle(_resume.value))
    val grammarIssues: StateFlow<List<GrammarIssue>> = _grammarIssues.asStateFlow()

    private val _selectedCategory = MutableStateFlow(ProfessionCategory.ALL)
    val selectedCategory: StateFlow<ProfessionCategory> = _selectedCategory.asStateFlow()

    private val _selectedColumnMode = MutableStateFlow(TemplateColumnMode.ALL)
    val selectedColumnMode: StateFlow<TemplateColumnMode> = _selectedColumnMode.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    private val _geminiKey = MutableStateFlow(
        prefs.getString("gemini_key", null)?.takeIf { it.isNotBlank() } ?: BuildConfig.GEMINI_API_KEY
    )
    val geminiKey: StateFlow<String> = _geminiKey.asStateFlow()

    private fun userResumeKey(): String {
        val email = _userEmail.value ?: "guest"
        return "resume_json_${email.hashCode()}"
    }

    private fun loadSaved(): ResumeData {
        val json = prefs.getString(userResumeKey(), null) ?: return ResumeData()
        return try {
            gson.fromJson(json, ResumeData::class.java) ?: ResumeData()
        } catch (_: Exception) {
            ResumeData()
        }
    }

    fun isLoggedIn(): Boolean = !_userEmail.value.isNullOrBlank()

    fun isTemplateUnlocked(spec: ResumeTemplateSpec): Boolean {
        if (isLoggedIn()) return true
        val indexInCategory = TemplateCatalog.all
            .filter { it.category == spec.category }
            .indexOfFirst { it.id == spec.id }
        return indexInCategory in 0..2
    }

    fun signIn(email: String, name: String) {
        val cleanEmail = email.trim().lowercase()
        if (!cleanEmail.contains("@")) return
        val cleanName = name.trim().ifBlank { cleanEmail.substringBefore("@") }
        prefs.edit()
            .putString("user_email", cleanEmail)
            .putString("user_name", cleanName)
            .apply()
        _userEmail.value = cleanEmail
        _userName.value = cleanName
        val loaded = loadSaved()
        _resume.value = loaded
        _ats.value = computeAts(loaded)
        _grammarIssues.value = AiResumeAssistant.checkGrammarAndStyle(loaded)
    }

    fun signOut() {
        prefs.edit().remove("user_email").remove("user_name").apply()
        _userEmail.value = null
        _userName.value = null
        val loaded = loadSaved()
        _resume.value = loaded
        _ats.value = computeAts(loaded)
        _grammarIssues.value = AiResumeAssistant.checkGrammarAndStyle(loaded)
    }

    fun saveGeminiKey(key: String) {
        val clean = key.trim()
        prefs.edit().putString("gemini_key", clean).apply()
        _geminiKey.value = clean.ifBlank { BuildConfig.GEMINI_API_KEY }
    }

    fun selectCategory(cat: ProfessionCategory) {
        _selectedCategory.value = cat
    }

    fun selectColumnMode(mode: TemplateColumnMode) {
        _selectedColumnMode.value = mode
    }

    fun selectTemplate(templateId: String) {
        update { it.copy(templateId = templateId, customAccentHex = null) }
    }

    fun update(transform: (ResumeData) -> ResumeData) {
        val next = transform(_resume.value)
        _resume.value = next
        _ats.value = computeAts(next)
        _grammarIssues.value = AiResumeAssistant.checkGrammarAndStyle(next)
        prefs.edit().putString(userResumeKey(), gson.toJson(next)).apply()
    }

    fun importResumeUri(context: Context, uri: Uri, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            _isAiLoading.value = true
            val parsed = withContext(Dispatchers.IO) {
                ResumeImporter.importFromUri(context, uri, _resume.value.templateId)
            }
            _isAiLoading.value = false
            if (parsed != null) {
                update { parsed }
                onDone(true)
            } else {
                onDone(false)
            }
        }
    }

    fun fixAllGrammar() {
        update { data ->
            data.copy(
                summary = AiResumeAssistant.autoFixText(data.summary),
                experiences = data.experiences.map { exp ->
                    exp.copy(bullets = AiResumeAssistant.autoFixText(exp.bullets))
                }
            )
        }
    }

    fun aiGenerateSummary() {
        viewModelScope.launch {
            _isAiLoading.value = true
            val res = AiResumeAssistant.generateSummary(
                _resume.value.jobTitle,
                _resume.value.skills,
                _geminiKey.value
            )
            update { it.copy(summary = res) }
            _isAiLoading.value = false
        }
    }

    fun aiUpgradeExperience(index: Int) {
        val exp = _resume.value.experiences.getOrNull(index) ?: return
        viewModelScope.launch {
            _isAiLoading.value = true
            val upgraded = AiResumeAssistant.upgradeBullets(exp.role, exp.bullets, _geminiKey.value)
            updateExperience(index) { it.copy(bullets = upgraded) }
            _isAiLoading.value = false
        }
    }

    fun aiSuggestSkills() {
        val suggested = AiResumeAssistant.suggestSkills(_resume.value.jobTitle)
        update { it.copy(skills = suggested) }
    }

    fun addExperience() = update { it.copy(experiences = it.experiences + ExperienceItem()) }
    fun updateExperience(index: Int, transform: (ExperienceItem) -> ExperienceItem) {
        update { data ->
            val list = data.experiences.toMutableList()
            if (index in list.indices) list[index] = transform(list[index])
            data.copy(experiences = list)
        }
    }
    fun removeExperience(index: Int) {
        update { data ->
            if (data.experiences.size <= 1) data
            else data.copy(experiences = data.experiences.filterIndexed { i, _ -> i != index })
        }
    }

    fun addEducation() = update { it.copy(educations = it.educations + EducationItem()) }
    fun updateEducation(index: Int, transform: (EducationItem) -> EducationItem) {
        update { data ->
            val list = data.educations.toMutableList()
            if (index in list.indices) list[index] = transform(list[index])
            data.copy(educations = list)
        }
    }
    fun removeEducation(index: Int) {
        update { data ->
            if (data.educations.size <= 1) data
            else data.copy(educations = data.educations.filterIndexed { i, _ -> i != index })
        }
    }

    fun addProject() = update { it.copy(projects = it.projects + ProjectItem()) }
    fun updateProject(index: Int, transform: (ProjectItem) -> ProjectItem) {
        update { data ->
            val list = data.projects.toMutableList()
            if (index in list.indices) list[index] = transform(list[index])
            data.copy(projects = list)
        }
    }
    fun removeProject(index: Int) {
        update { data ->
            if (data.projects.size <= 1) data
            else data.copy(projects = data.projects.filterIndexed { i, _ -> i != index })
        }
    }

    fun addAchievement() = update { it.copy(achievements = it.achievements + AchievementItem()) }
    fun updateAchievement(index: Int, transform: (AchievementItem) -> AchievementItem) {
        update { data ->
            val list = data.achievements.toMutableList()
            if (index in list.indices) list[index] = transform(list[index])
            data.copy(achievements = list)
        }
    }
    fun removeAchievement(index: Int) {
        update { data ->
            if (data.achievements.size <= 1) data
            else data.copy(achievements = data.achievements.filterIndexed { i, _ -> i != index })
        }
    }

    fun addLanguage() = update { it.copy(languages = it.languages + LanguageItem()) }
    fun updateLanguage(index: Int, transform: (LanguageItem) -> LanguageItem) {
        update { data ->
            val list = data.languages.toMutableList()
            if (index in list.indices) list[index] = transform(list[index])
            data.copy(languages = list)
        }
    }
    fun removeLanguage(index: Int) {
        update { data ->
            if (data.languages.size <= 1) data
            else data.copy(languages = data.languages.filterIndexed { i, _ -> i != index })
        }
    }

    fun loadSample() {
        update {
            ResumeData(
                fullName = "Mayank Parekh",
                jobTitle = "Executive Engineer — Manufacturing & Operations",
                email = "mayankparekh567@gmail.com",
                phone = "+91 98765 43210",
                location = "Anand, Gujarat",
                linkedin = "linkedin.com/in/mayankparekh",
                summary = "Results-driven Executive Engineer with expertise in CNC/VMC operations, Kaizen, 5S, and TPM. Proven track record in reducing cycle times and digitizing quality inspection workflows.",
                skills = "Kaizen, 5S, Total Productive Maintenance (TPM), CNC & VMC Operations, MES Dashboards, Process Optimization",
                hobbies = "Technology, Continuous Improvement, Reading",
                experiences = listOf(
                    ExperienceItem(
                        id = "e1",
                        role = "Executive Engineer (Gear Division)",
                        company = "Elecon Engineering Company Limited",
                        duration = "2018 – Present",
                        bullets = "• Introduced proof machining on hollow shafts prior to deep hole drilling, reducing cycle time by 18%\n• Implemented 5S and Kaizen initiatives across shop floor teams to improve safety and OEE\n• Digitized First Piece Trial quality checks for error-free dispatch"
                    )
                ),
                educations = listOf(
                    EducationItem(id = "ed1", degree = "B.E. Mechanical Engineering", institution = "Gujarat Technological University", year = "2014")
                ),
                projects = listOf(
                    ProjectItem(id = "p1", title = "MES WIP Real-Time Dashboard", techStack = "Shop Floor Digitization", description = "Automated delay alerts and WIP inventory tracking to boost OEE.")
                ),
                achievements = listOf(
                    AchievementItem(id = "a1", title = "Kaizen Best Process Improvement Award", year = "2023")
                ),
                languages = listOf(
                    LanguageItem(id = "l1", name = "English", level = "Fluent"),
                    LanguageItem(id = "l2", name = "Gujarati", level = "Native"),
                    LanguageItem(id = "l3", name = "Hindi", level = "Fluent")
                ),
                templateId = it.templateId,
                customAccentHex = it.customAccentHex,
                fontScale = it.fontScale,
                forceSerif = it.forceSerif,
                compactSpacing = it.compactSpacing
            )
        }
    }

    private fun computeAts(d: ResumeData): AtsReport {
        var score = 0
        val tips = mutableListOf<String>()

        if (d.fullName.isNotBlank() && d.email.contains("@") && d.phone.isNotBlank()) score += 20
        else tips.add("Add full name, valid email, and phone number.")

        if (d.summary.length >= 60) score += 15
        else tips.add("Write a 2–3 line Professional Summary (60+ characters).")

        val filledExp = d.experiences.filter { it.role.isNotBlank() && it.company.isNotBlank() }
        if (filledExp.isNotEmpty()) score += 25
        else tips.add("Add at least one Work Experience entry.")

        val hasMetrics = filledExp.any { it.bullets.contains("%") || Regex("\\d+").containsMatchIn(it.bullets) }
        if (hasMetrics) score += 15
        else tips.add("Include numbers or % metrics in your bullet points (e.g., 'reduced cycle time by 18%').")

        val skillCount = d.skills.split(",").map { it.trim() }.count { it.isNotBlank() }
        if (skillCount >= 5) score += 15
        else tips.add("List at least 5 comma-separated Core Skills.")

        if (d.educations.any { it.degree.isNotBlank() }) score += 10
        else tips.add("Add your Education degree and institution.")

        return AtsReport(score.coerceAtMost(100), tips)
    }
}
