package com.resumebuilder.pro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.lifecycle.viewmodel.compose.viewModel
import com.resumebuilder.pro.ui.ResumeScreen
import com.resumebuilder.pro.ui.ResumeViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                val vm: ResumeViewModel = viewModel()
                ResumeScreen(vm)
            }
        }
    }
}
