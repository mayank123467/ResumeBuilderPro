package com.resumebuilder.pro.ai

import android.content.Context
import android.net.Uri
import com.resumebuilder.pro.model.*
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.Inflater
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ResumeImporter {
    fun importFromUri(context: Context, uri: Uri, currentTemplateId: String): ResumeData? {
        val rawBytes = try {
            context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        } catch (_: Exception) {
            return null
        }

        val mime = context.contentResolver.getType(uri).orEmpty().lowercase()
        val pathName = uri.lastPathSegment.orEmpty().lowercase()

        val extractedText = when {
            mime.contains("pdf") || pathName.endsWith(".pdf") ||
                (rawBytes.size >= 4 && String(rawBytes, 0, 4) == "%PDF") -> extractTextFromPdfBytes(rawBytes)

            mime.contains("wordprocessingml") || pathName.endsWith(".docx") ||
                (rawBytes.size >= 2 && rawBytes[0] == 0x50.toByte() && rawBytes[1] == 0x4B.toByte()) -> extractTextFromDocxBytes(rawBytes)

            mime.contains("html") || pathName.endsWith(".html") || pathName.endsWith(".htm") -> {
                val cleanText = extractTextFromHtml(String(rawBytes, Charsets.UTF_8))
                // Convert HTML to a background DOCX file and extract from it
                val docxBytes = convertTextToDocxBytes(context, cleanText)
                if (docxBytes != null) extractTextFromDocxBytes(docxBytes) else cleanText
            }

            mime.contains("msword") || pathName.endsWith(".doc") ->
                String(rawBytes, Charsets.ISO_8859_1).replace(Regex("[^\\x20-\\x7E\\n]"), " ")

            else -> String(rawBytes, Charsets.UTF_8)
        }

        if (extractedText.isBlank()) return null
        return parseResumeText(extractedText, currentTemplateId)
    }

    private fun extractTextFromDocxBytes(bytes: ByteArray): String {
        return try {
            ZipInputStream(ByteArrayInputStream(bytes)).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (entry.name == "word/document.xml") {
                        val xml = zis.readBytes().toString(Charsets.UTF_8)
                        return xml
                            .replace(Regex("</w:p>"), "\n")
                            .replace(Regex("<[^>]+>"), " ")
                            .replace("&amp;", "&")
                            .replace("&lt;", "<")
                            .replace("&gt;", ">")
                            .replace(Regex("[ \\t]+"), " ")
                            .trim()
                    }
                    entry = zis.nextEntry
                }
                ""
            }
        } catch (_: Exception) {
            ""
        }
    }

    private fun extractTextFromHtml(html: String): String {
        return html
            .replace(Regex("(?is)<script[^>]*>.*?</script>"), " ")
            .replace(Regex("(?is)<style[^>]*>.*?</style>"), " ")
            .replace(Regex("(?i)<(?:br|p|div|li|h[1-6]|tr)[^>]*>"), "\n")
            .replace(Regex("<[^>]+>"), " ")
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace(Regex("[ \\t]+"), " ")
            .trim()
    }

    private fun convertTextToDocxBytes(context: Context, text: String): ByteArray? {
        return try {
            val escaped = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            val paragraphs = escaped.lines().filter { it.isNotBlank() }.joinToString("") { line ->
                "<w:p><w:r><w:t>$line</w:t></w:r></w:p>"
            }
            val docXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
                <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
                <w:body>$paragraphs</w:body></w:document>""".trimIndent()

            val baos = ByteArrayOutputStream()
            ZipOutputStream(baos).use { zos ->
                zos.putNextEntry(ZipEntry("word/document.xml"))
                zos.write(docXml.toByteArray(Charsets.UTF_8))
                zos.closeEntry()
            }
            val outBytes = baos.toByteArray()
            val dir = File(context.cacheDir, "converted").apply { mkdirs() }
            FileOutputStream(File(dir, "imported_resume.docx")).use { it.write(outBytes) }
            outBytes
        } catch (_: Exception) {
            null
        }
    }

    private fun extractTextFromPdfBytes(bytes: ByteArray): String {
        val sb = StringBuilder()
        val raw = String(bytes, Charsets.ISO_8859_1)
        val textParen = Regex("\\(([^()\\\\]{2,200})\\)\\s*(?:Tj|')")
        textParen.findAll(raw).forEach { m -> sb.append(m.groupValues[1]).append(" ") }

        val streamRegex = Regex("stream\\r?\\n([\\s\\S]*?)\\r?\\nendstream")
        streamRegex.findAll(raw).forEach { m ->
            val streamBytes = m.groupValues[1].toByteArray(Charsets.ISO_8859_1)
            try {
                val inflater = Inflater()
                inflater.setInput(streamBytes)
                val out = ByteArrayOutputStream()
                val buf = ByteArray(2048)
                while (!inflater.finished()) {
                    val count = inflater.inflate(buf)
                    if (count == 0) break
                    out.write(buf, 0, count)
                }
                inflater.end()
                val decoded = out.toString(Charsets.ISO_8859_1.name())
                textParen.findAll(decoded).forEach { pm -> sb.append(pm.groupValues[1]).append("\n") }
            } catch (_: Exception) { }
        }

        val result = sb.toString().replace(Regex("\\s+"), " ").trim()
        return if (result.length > 30) result else raw.replace(Regex("[^\\x20-\\x7E\\n]"), " ")
    }

    private fun parseResumeText(text: String, templateId: String): ResumeData {
        val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
        val email = Regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}").find(text)?.value.orEmpty()
        val phone = Regex("(\\+?\\d[\\d\\s-]{8,14}\\d)").find(text)?.value.orEmpty()
        val linkedin = Regex("(?:https?://)?(?:www\\.)?linkedin\\.com/in/[A-Za-z0-9_-]+").find(text)?.value.orEmpty()

        val nameCandidate = lines.firstOrNull { line ->
            !line.contains("@") && !line.contains("http") && line.length in 3..45
        }.orEmpty()

        val summaryMatch = Regex("(?is)(?:summary|profile|objective)[:\\s]+(.*?)(?=experience|education|skills|projects|$)").find(text)
        val summary = summaryMatch?.groupValues?.getOrNull(1)?.trim()?.take(400).orEmpty()

        val skillsMatch = Regex("(?is)(?:skills|technologies|competencies)[:\\s]+(.*?)(?=experience|education|projects|languages|hobbies|$)").find(text)
        val skills = skillsMatch?.groupValues?.getOrNull(1)?.trim()?.take(300).orEmpty()

        val hobbiesMatch = Regex("(?is)(?:hobbies|interests)[:\\s]+(.*?)(?=experience|education|skills|projects|languages|$)").find(text)
        val hobbies = hobbiesMatch?.groupValues?.getOrNull(1)?.trim()?.take(200).orEmpty()

        val expMatch = Regex("(?is)(?:experience|employment|work history)[:\\s]+(.*?)(?=education|skills|projects|achievements|$)").find(text)
        val expText = expMatch?.groupValues?.getOrNull(1)?.trim()?.take(500).orEmpty()

        val eduMatch = Regex("(?is)(?:education|academic|qualification)[:\\s]+(.*?)(?=skills|projects|achievements|hobbies|$)").find(text)
        val eduText = eduMatch?.groupValues?.getOrNull(1)?.trim()?.take(250).orEmpty()

        val langList = listOf("English", "Hindi", "Gujarati", "Marathi", "Tamil", "Telugu", "Spanish", "French", "German")
            .filter { text.contains(it, ignoreCase = true) }
            .mapIndexed { idx, l -> LanguageItem("imp_lang_$idx", l, "Fluent") }
            .ifEmpty { listOf(LanguageItem("lang_1", "English", "Fluent")) }

        return ResumeData(
            fullName = nameCandidate,
            jobTitle = lines.getOrNull(1)?.take(60).orEmpty(),
            email = email,
            phone = phone,
            linkedin = linkedin,
            summary = summary.ifBlank { text.take(220) },
            skills = skills,
            hobbies = hobbies,
            experiences = if (expText.isNotBlank()) listOf(ExperienceItem(id = "imp_exp", role = "Imported Experience", bullets = expText)) else listOf(ExperienceItem()),
            educations = if (eduText.isNotBlank()) listOf(EducationItem("imp_edu", eduText.take(80), "", "")) else listOf(EducationItem()),
            languages = langList,
            templateId = templateId
        )
    }
}
