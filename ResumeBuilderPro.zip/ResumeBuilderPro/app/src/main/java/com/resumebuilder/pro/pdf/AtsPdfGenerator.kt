package com.resumebuilder.pro.pdf

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.resumebuilder.pro.model.ResumeData
import com.resumebuilder.pro.model.TemplateCatalog
import com.resumebuilder.pro.model.TemplateLayout
import java.io.File
import java.io.FileOutputStream

object AtsPdfGenerator {
    fun generatePdf(context: Context, data: ResumeData): File {
        val spec = TemplateCatalog.byId(data.templateId)
        val doc = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val margin = if (spec.layout == TemplateLayout.BOLD_SIDE_STRIPE) 48f else 42f
        val maxTextWidth = pageWidth - margin - 42f

        var pageNum = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
        var canvas = page.canvas
        var y = 52f

        val accentColor = (data.customAccentHex ?: spec.accentHex).toInt()
        val secondaryColor = spec.secondaryHex.toInt()
        val useSerif = data.forceSerif ?: spec.useSerif
        val baseFamily = if (useSerif) Typeface.SERIF else Typeface.SANS_SERIF
        val fs = data.fontScale
        val lineStep = if (data.compactSpacing) 12.5f else 14.5f

        val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (spec.layout == TemplateLayout.EXECUTIVE_BANNER) Color.WHITE else accentColor
            textSize = 22f * fs
            typeface = Typeface.create(baseFamily, Typeface.BOLD)
        }
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (spec.layout == TemplateLayout.EXECUTIVE_BANNER) Color.rgb(230, 238, 248) else Color.DKGRAY
            textSize = 12f * fs
            typeface = Typeface.create(baseFamily, Typeface.NORMAL)
        }
        val sectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            textSize = 11.5f * fs
            typeface = Typeface.create(baseFamily, Typeface.BOLD)
        }
        val bodyBoldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 10.5f * fs
            typeface = Typeface.create(baseFamily, Typeface.BOLD)
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(35, 35, 35)
            textSize = 10f * fs
            typeface = Typeface.create(baseFamily, Typeface.NORMAL)
        }
        val linePaint = Paint().apply {
            color = accentColor
            strokeWidth = if (spec.layout == TemplateLayout.MODERN_ACCENT_BAR) 1.5f else 0.9f
        }
        val bannerPaint = Paint().apply { color = accentColor }
        val tintPaint = Paint().apply { color = secondaryColor }

        fun drawPageDecorations() {
            if (spec.layout == TemplateLayout.BOLD_SIDE_STRIPE) {
                canvas.drawRect(0f, 0f, 12f, pageHeight.toFloat(), bannerPaint)
            } else if (spec.layout == TemplateLayout.MODERN_ACCENT_BAR && pageNum == 1) {
                canvas.drawRect(0f, 0f, pageWidth.toFloat(), 8f, bannerPaint)
            }
        }
        drawPageDecorations()

        fun ensureSpace(needed: Float) {
            if (y + needed > pageHeight - 40f) {
                doc.finishPage(page)
                pageNum++
                page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
                canvas = page.canvas
                drawPageDecorations()
                y = 48f
            }
        }

        fun drawWrapped(text: String, paint: Paint, x: Float, lineHeight: Float) {
            val words = text.split(" ")
            var line = StringBuilder()
            for (word in words) {
                val test = if (line.isEmpty()) word else "$line $word"
                if (paint.measureText(test) > maxTextWidth - (x - margin)) {
                    ensureSpace(lineHeight)
                    canvas.drawText(line.toString(), x, y, paint)
                    y += lineHeight
                    line = StringBuilder(word)
                } else {
                    line = StringBuilder(test)
                }
            }
            if (line.isNotEmpty()) {
                ensureSpace(lineHeight)
                canvas.drawText(line.toString(), x, y, paint)
                y += lineHeight
            }
        }

        fun drawSectionHeader(title: String) {
            y += 8f
            ensureSpace(24f)
            if (spec.layout == TemplateLayout.TECH_GRID_HEADER) {
                canvas.drawRect(margin, y - 12f, pageWidth - 42f, y + 5f, tintPaint)
            }
            canvas.drawText(title.uppercase(), margin, y, sectionPaint)
            y += 6f
            if (spec.layout != TemplateLayout.TECH_GRID_HEADER) {
                canvas.drawLine(margin, y, pageWidth - 42f, y, linePaint)
            }
            y += 14f
        }

        if (spec.layout == TemplateLayout.EXECUTIVE_BANNER) {
            canvas.drawRect(0f, 0f, pageWidth.toFloat(), 108f, bannerPaint)
            y = 44f
        }

        canvas.drawText(data.fullName.ifBlank { "Your Name" }, margin, y, namePaint)
        y += 18f
        if (data.jobTitle.isNotBlank()) {
            canvas.drawText(data.jobTitle, margin, y, titlePaint)
            y += 16f
        }
        val contactLine = listOf(data.email, data.phone, data.location, data.linkedin)
            .filter { it.isNotBlank() }
            .joinToString("  |  ")
        if (contactLine.isNotBlank()) {
            val contactPaint = if (spec.layout == TemplateLayout.EXECUTIVE_BANNER) titlePaint else bodyPaint
            drawWrapped(contactLine, contactPaint, margin, lineStep)
        }
        if (spec.layout == TemplateLayout.EXECUTIVE_BANNER && y < 118f) {
            y = 122f
        }

        if (data.summary.isNotBlank()) {
            drawSectionHeader("Professional Summary")
            drawWrapped(data.summary, bodyPaint, margin, lineStep)
        }

        val validExp = data.experiences.filter { it.role.isNotBlank() || it.company.isNotBlank() }
        if (validExp.isNotEmpty()) {
            drawSectionHeader("Work Experience")
            for (exp in validExp) {
                ensureSpace(32f)
                val header = listOf(exp.role, exp.company).filter { it.isNotBlank() }.joinToString(" — ")
                canvas.drawText(header, margin, y, bodyBoldPaint)
                if (exp.duration.isNotBlank()) {
                    val dw = bodyPaint.measureText(exp.duration)
                    canvas.drawText(exp.duration, pageWidth - 42f - dw, y, bodyPaint)
                }
                y += 14f
                exp.bullets.lines().map { it.trim() }.filter { it.isNotBlank() }.forEach { bullet ->
                    val clean = if (bullet.startsWith("•") || bullet.startsWith("-")) bullet else "• $bullet"
                    drawWrapped(clean, bodyPaint, margin + 8f, lineStep)
                }
                y += 6f
            }
        }

        val validEdu = data.educations.filter { it.degree.isNotBlank() || it.institution.isNotBlank() }
        if (validEdu.isNotEmpty()) {
            drawSectionHeader("Education")
            for (edu in validEdu) {
                ensureSpace(22f)
                val line = listOf(edu.degree, edu.institution).filter { it.isNotBlank() }.joinToString(" — ")
                canvas.drawText(line, margin, y, bodyBoldPaint)
                if (edu.year.isNotBlank()) {
                    val yw = bodyPaint.measureText(edu.year)
                    canvas.drawText(edu.year, pageWidth - 42f - yw, y, bodyPaint)
                }
                y += 15f
            }
        }

        if (data.skills.isNotBlank()) {
            drawSectionHeader("Core Skills")
            drawWrapped(data.skills, bodyPaint, margin, lineStep)
        }

        doc.finishPage(page)

        val dir = File(context.cacheDir, "resumes").apply { mkdirs() }
        val safeName = data.fullName.replace(Regex("[^A-Za-z0-9]"), "_").ifBlank { "Resume" }
        val outFile = File(dir, "${safeName}_ATS_Resume.pdf")
        FileOutputStream(outFile).use { doc.writeTo(it) }
        doc.close()
        return outFile
    }
}
