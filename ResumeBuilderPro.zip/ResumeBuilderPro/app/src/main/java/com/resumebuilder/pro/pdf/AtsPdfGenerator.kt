package com.resumebuilder.pro.pdf

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.resumebuilder.pro.model.ResumeData
import java.io.File
import java.io.FileOutputStream

object AtsPdfGenerator {
    fun generatePdf(context: Context, data: ResumeData): File {
        val doc = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val margin = 42f
        val maxTextWidth = pageWidth - margin * 2

        var pageNum = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
        var canvas = page.canvas
        var y = 52f

        val accentColor = data.template.accentHex.toInt()
        val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            textSize = 22f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.DKGRAY
            textSize = 12f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }
        val sectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            textSize = 11.5f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val bodyBoldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 10.5f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(35, 35, 35)
            textSize = 10f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }
        val linePaint = Paint().apply {
            color = accentColor
            strokeWidth = 1f
        }

        fun ensureSpace(needed: Float) {
            if (y + needed > pageHeight - 40f) {
                doc.finishPage(page)
                pageNum++
                page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
                canvas = page.canvas
                y = 48f
            }
        }

        fun drawWrapped(text: String, paint: Paint, x: Float, lineHeight: Float) {
            val words = text.split(" ")
            var line = StringBuilder()
            for (word in words) {
                val test = if (line.isEmpty()) word else "$line $word"
                if (paint.measureText(test) > maxTextWidth - (x - margin)) {
                    ensureSpace(lineHeight)
                    canvas.drawText(line.toString(), x, y, paint)
                    y += lineHeight
                    line = StringBuilder(word)
                } else {
                    line = StringBuilder(test)
                }
            }
            if (line.isNotEmpty()) {
                ensureSpace(lineHeight)
                canvas.drawText(line.toString(), x, y, paint)
                y += lineHeight
            }
        }

        fun drawSectionHeader(title: String) {
            y += 8f
            ensureSpace(24f)
            canvas.drawText(title.uppercase(), margin, y, sectionPaint)
            y += 5f
            canvas.drawLine(margin, y, pageWidth - margin, y, linePaint)
            y += 14f
        }

        // Header
        canvas.drawText(data.fullName.ifBlank { "Your Name" }, margin, y, namePaint)
        y += 18f
        if (data.jobTitle.isNotBlank()) {
            canvas.drawText(data.jobTitle, margin, y, titlePaint)
            y += 16f
        }
        val contactLine = listOf(data.email, data.phone, data.location, data.linkedin)
            .filter { it.isNotBlank() }
            .joinToString("  |  ")
        if (contactLine.isNotBlank()) {
            drawWrapped(contactLine, bodyPaint, margin, 14f)
        }

        if (data.summary.isNotBlank()) {
            drawSectionHeader("Professional Summary")
            drawWrapped(data.summary, bodyPaint, margin, 14f)
        }

        val validExp = data.experiences.filter { it.role.isNotBlank() || it.company.isNotBlank() }
        if (validExp.isNotEmpty()) {
            drawSectionHeader("Work Experience")
            for (exp in validExp) {
                ensureSpace(32f)
                val header = listOf(exp.role, exp.company).filter { it.isNotBlank() }.joinToString(" — ")
                canvas.drawText(header, margin, y, bodyBoldPaint)
                if (exp.duration.isNotBlank()) {
                    val dw = bodyPaint.measureText(exp.duration)
                    canvas.drawText(exp.duration, pageWidth - margin - dw, y, bodyPaint)
                }
                y += 14f
                exp.bullets.lines().map { it.trim() }.filter { it.isNotBlank() }.forEach { bullet ->
                    val clean = if (bullet.startsWith("•") || bullet.startsWith("-")) bullet else "• $bullet"
                    drawWrapped(clean, bodyPaint, margin + 8f, 13.5f)
                }
                y += 6f
            }
        }

        val validEdu = data.educations.filter { it.degree.isNotBlank() || it.institution.isNotBlank() }
        if (validEdu.isNotEmpty()) {
            drawSectionHeader("Education")
            for (edu in validEdu) {
                ensureSpace(22f)
                val line = listOf(edu.degree, edu.institution).filter { it.isNotBlank() }.joinToString(" — ")
                canvas.drawText(line, margin, y, bodyBoldPaint)
                if (edu.year.isNotBlank()) {
                    val yw = bodyPaint.measureText(edu.year)
                    canvas.drawText(edu.year, pageWidth - margin - yw, y, bodyPaint)
                }
                y += 15f
            }
        }

        if (data.skills.isNotBlank()) {
            drawSectionHeader("Core Skills")
            drawWrapped(data.skills, bodyPaint, margin, 14f)
        }

        doc.finishPage(page)

        val dir = File(context.cacheDir, "resumes").apply { mkdirs() }
        val safeName = data.fullName.replace(Regex("[^A-Za-z0-9]"), "_").ifBlank { "Resume" }
        val outFile = File(dir, "${safeName}_ATS_Resume.pdf")
        FileOutputStream(outFile).use { doc.writeTo(it) }
        doc.close()
        return outFile
    }
}
