package com.resumebuilder.pro.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Path
import android.graphics.RectF
import android.util.Base64
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.resumebuilder.pro.model.ResumeData
import com.resumebuilder.pro.model.TemplateCatalog
import com.resumebuilder.pro.model.TemplateLayout
import java.io.File
import java.io.FileOutputStream

object AtsPdfGenerator {
    fun generatePdf(context: Context, data: ResumeData): File {
        val spec = TemplateCatalog.byId(data.templateId)
        val doc = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val accentColor = (data.customAccentHex ?: spec.accentHex).toInt()
        val secondaryColor = spec.secondaryHex.toInt()
        val useSerif = data.forceSerif ?: spec.useSerif
        val baseFamily = if (useSerif) Typeface.SERIF else Typeface.SANS_SERIF
        val fs = data.fontScale
        val lineStep = if (data.compactSpacing) 12.5f else 14.2f

        val isDarkSidebar = spec.layout == TemplateLayout.TWO_COL_DARK_SIDEBAR
        val isTwoCol = !data.atsModeEnabled && spec.layout.isTwoColumn

        var pageNum = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
        var canvas = page.canvas

        val sidebarW = 185f
        val leftMargin = if (isTwoCol) 20f else 42f
        val rightColX = if (isTwoCol) sidebarW + 20f else 42f
        val rightColWidth = pageWidth - rightColX - 28f

        val bannerPaint = Paint().apply { color = accentColor }
        val tintPaint = Paint().apply { color = secondaryColor }
        val darkSidebarPaint = Paint().apply { color = Color.rgb(15, 23, 42) }

        val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (spec.layout == TemplateLayout.EXECUTIVE_BANNER || spec.layout == TemplateLayout.TWO_COL_CANVA_BOLD) Color.WHITE else accentColor
            textSize = 20f * fs
            typeface = Typeface.create(baseFamily, Typeface.BOLD)
        }
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (spec.layout == TemplateLayout.EXECUTIVE_BANNER || spec.layout == TemplateLayout.TWO_COL_CANVA_BOLD) Color.rgb(226, 232, 240) else Color.DKGRAY
            textSize = 11.5f * fs
            typeface = Typeface.create(baseFamily, Typeface.NORMAL)
        }
        val sectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = accentColor
            textSize = 11f * fs
            typeface = Typeface.create(baseFamily, Typeface.BOLD)
        }
        val sideSectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (isDarkSidebar) Color.rgb(147, 197, 253) else accentColor
            textSize = 10.5f * fs
            typeface = Typeface.create(baseFamily, Typeface.BOLD)
        }
        val sideBodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (isDarkSidebar) Color.rgb(226, 232, 240) else Color.rgb(30, 41, 59)
            textSize = 9.5f * fs
            typeface = Typeface.create(baseFamily, Typeface.NORMAL)
        }
        val bodyBoldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 10.2f * fs
            typeface = Typeface.create(baseFamily, Typeface.BOLD)
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(35, 35, 35)
            textSize = 9.8f * fs
            typeface = Typeface.create(baseFamily, Typeface.NORMAL)
        }
        val linePaint = Paint().apply {
            color = accentColor
            strokeWidth = 1f
        }

        fun drawDecorations() {
            if (isTwoCol) {
                canvas.drawRect(0f, 0f, sidebarW, pageHeight.toFloat(), if (isDarkSidebar) darkSidebarPaint else tintPaint)
                if (spec.layout == TemplateLayout.TWO_COL_CANVA_BOLD && pageNum == 1) {
                    canvas.drawRect(0f, 0f, pageWidth.toFloat(), 96f, bannerPaint)
                }
            } else if (spec.layout == TemplateLayout.EXECUTIVE_BANNER && pageNum == 1) {
                canvas.drawRect(0f, 0f, pageWidth.toFloat(), 102f, bannerPaint)
            } else if (spec.layout == TemplateLayout.MODERN_ACCENT_BAR && pageNum == 1) {
                canvas.drawRect(0f, 0f, pageWidth.toFloat(), 8f, bannerPaint)
            }
        }
        drawDecorations()

        var y = if (spec.layout == TemplateLayout.EXECUTIVE_BANNER || spec.layout == TemplateLayout.TWO_COL_CANVA_BOLD) 40f else 48f
        var sideY = if (spec.layout == TemplateLayout.TWO_COL_CANVA_BOLD) 118f else 48f

        fun drawWrapped(text: String, paint: Paint, x: Float, maxW: Float, curY: Float): Float {
            var yy = curY
            val words = text.split(" ")
            var line = StringBuilder()
            for (word in words) {
                val test = if (line.isEmpty()) word else "$line $word"
                if (paint.measureText(test) > maxW) {
                    if (yy + lineStep > pageHeight - 36f) break
                    canvas.drawText(line.toString(), x, yy, paint)
                    yy += lineStep
                    line = StringBuilder(word)
                } else {
                    line = StringBuilder(test)
                }
            }
            if (line.isNotEmpty() && yy + lineStep <= pageHeight - 36f) {
                canvas.drawText(line.toString(), x, yy, paint)
                yy += lineStep
            }
            return yy
        }

        if (isTwoCol) {
            if (!data.profilePhotoBase64.isNullOrBlank()) {
                try {
                    val bytes = Base64.decode(data.profilePhotoBase64, Base64.DEFAULT)
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (bmp != null) {
                        val size = 56f
                        val cx = leftMargin + size / 2f
                        val cy = sideY + size / 2f
                        val clip = Path().apply { addCircle(cx, cy, size / 2f, Path.Direction.CW) }
                        canvas.save()
                        canvas.clipPath(clip)
                        val scaled = Bitmap.createScaledBitmap(bmp, size.toInt(), size.toInt(), true)
                        canvas.drawBitmap(scaled, null, RectF(leftMargin, sideY, leftMargin + size, sideY + size), null)
                        canvas.restore()
                        sideY += size + 10f
                    }
                } catch (_: Exception) {}
            }
            // Header
            if (spec.layout == TemplateLayout.TWO_COL_CANVA_BOLD) {
                canvas.drawText(data.fullName.ifBlank { "Your Name" }, 24f, y, namePaint)
                y += 18f
                if (data.jobTitle.isNotBlank()) canvas.drawText(data.jobTitle, 24f, y, titlePaint)
                y = 118f
            } else {
                sideY = drawWrapped(data.fullName.ifBlank { "Your Name" }, namePaint.apply {
                    if (!isDarkSidebar) color = accentColor else color = Color.WHITE
                }, leftMargin, sidebarW - 30f, sideY)
                if (data.jobTitle.isNotBlank()) {
                    sideY = drawWrapped(data.jobTitle, sideBodyPaint, leftMargin, sidebarW - 30f, sideY + 2f)
                }
                sideY += 10f
            }

            // Left Sidebar: Contact, Skills, Languages, Hobbies
            canvas.drawText("CONTACT", leftMargin, sideY, sideSectionPaint)
            sideY += 13f
            listOf(data.email, data.phone, data.location, data.linkedin).filter { it.isNotBlank() }.forEach { c ->
                sideY = drawWrapped(c, sideBodyPaint, leftMargin, sidebarW - 30f, sideY)
            }

            if (data.skills.isNotBlank()) {
                sideY += 10f
                canvas.drawText("SKILLS", leftMargin, sideY, sideSectionPaint)
                sideY += 13f
                data.skills.split(",").map { it.trim() }.filter { it.isNotBlank() }.forEach { sk ->
                    sideY = drawWrapped("• $sk", sideBodyPaint, leftMargin, sidebarW - 30f, sideY)
                }
            }

            val validLangs = data.languages.filter { it.name.isNotBlank() }
            if (validLangs.isNotEmpty()) {
                sideY += 10f
                canvas.drawText("LANGUAGES", leftMargin, sideY, sideSectionPaint)
                sideY += 13f
                validLangs.forEach { l ->
                    sideY = drawWrapped("• ${l.name} (${l.level})", sideBodyPaint, leftMargin, sidebarW - 30f, sideY)
                }
            }

            if (data.hobbies.isNotBlank()) {
                sideY += 10f
                canvas.drawText("HOBBIES", leftMargin, sideY, sideSectionPaint)
                sideY += 13f
                sideY = drawWrapped(data.hobbies, sideBodyPaint, leftMargin, sidebarW - 30f, sideY)
            }
        } else {
            // Single-Column Header
            canvas.drawText(data.fullName.ifBlank { "Your Name" }, leftMargin, y, namePaint)
            y += 18f
            if (data.jobTitle.isNotBlank()) {
                canvas.drawText(data.jobTitle, leftMargin, y, titlePaint)
                y += 15f
            }
            val contactLine = listOf(data.email, data.phone, data.location, data.linkedin).filter { it.isNotBlank() }.joinToString(" | ")
            if (contactLine.isNotBlank()) {
                val cp = if (spec.layout == TemplateLayout.EXECUTIVE_BANNER) titlePaint else bodyPaint
                y = drawWrapped(contactLine, cp, leftMargin, rightColWidth, y)
            }
            if (spec.layout == TemplateLayout.EXECUTIVE_BANNER && y < 114f) y = 118f
        }

        fun ensureMainSpace(needed: Float) {
            if (y + needed > pageHeight - 38f) {
                doc.finishPage(page)
                pageNum++
                page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
                canvas = page.canvas
                drawDecorations()
                y = 48f
            }
        }

        fun mainHeader(title: String) {
            y += 6f
            ensureMainSpace(24f)
            canvas.drawText(title.uppercase(), rightColX, y, sectionPaint)
            y += 5f
            canvas.drawLine(rightColX, y, pageWidth - 28f, y, linePaint)
            y += 13f
        }

        if (data.summary.isNotBlank()) {
            mainHeader("Professional Summary")
            y = drawWrapped(data.summary, bodyPaint, rightColX, rightColWidth, y)
        }

        val validExp = data.experiences.filter { it.role.isNotBlank() || it.company.isNotBlank() }
        if (validExp.isNotEmpty()) {
            mainHeader(data.expSectionTitle())
            for (exp in validExp) {
                ensureMainSpace(30f)
                val hdr = listOf(exp.role, exp.company).filter { it.isNotBlank() }.joinToString(" — ")
                canvas.drawText(hdr, rightColX, y, bodyBoldPaint)
                if (exp.duration.isNotBlank()) {
                    val dw = bodyPaint.measureText(exp.duration)
                    canvas.drawText(exp.duration, pageWidth - 28f - dw, y, bodyPaint)
                }
                y += 13f
                exp.bullets.lines().map { it.trim() }.filter { it.isNotBlank() }.forEach { b ->
                    val clean = if (b.startsWith("•") || b.startsWith("-")) b else "• $b"
                    y = drawWrapped(clean, bodyPaint, rightColX + 6f, rightColWidth - 6f, y)
                }
                y += 5f
            }
        }

        val validProj = data.projects.filter { it.title.isNotBlank() }
        if (validProj.isNotEmpty()) {
            mainHeader("Projects")
            for (proj in validProj) {
                ensureMainSpace(26f)
                val hdr = listOf(proj.title, proj.techStack).filter { it.isNotBlank() }.joinToString(" | ")
                canvas.drawText(hdr, rightColX, y, bodyBoldPaint)
                y += 13f
                if (proj.description.isNotBlank()) {
                    y = drawWrapped("• ${proj.description}", bodyPaint, rightColX + 6f, rightColWidth - 6f, y)
                }
                y += 4f
            }
        }

        val validEdu = data.educations.filter { it.degree.isNotBlank() || it.institution.isNotBlank() }
        if (validEdu.isNotEmpty()) {
            mainHeader("Education")
            for (edu in validEdu) {
                ensureMainSpace(20f)
                val line = listOf(edu.degree, edu.institution).filter { it.isNotBlank() }.joinToString(" — ")
                canvas.drawText(line, rightColX, y, bodyBoldPaint)
                if (edu.year.isNotBlank()) {
                    val yw = bodyPaint.measureText(edu.year)
                    canvas.drawText(edu.year, pageWidth - 28f - yw, y, bodyPaint)
                }
                y += 14f
            }
        }

        val validAch = data.achievements.filter { it.title.isNotBlank() }
        if (validAch.isNotEmpty()) {
            mainHeader("Achievements & Awards")
            for (ach in validAch) {
                ensureMainSpace(18f)
                val label = listOf(ach.title, ach.year).filter { it.isNotBlank() }.joinToString(" (") + if (ach.year.isNotBlank()) ")" else ""
                y = drawWrapped("• $label", bodyPaint, rightColX + 6f, rightColWidth - 6f, y)
            }
        }

        if (!isTwoCol) {
            if (data.skills.isNotBlank()) {
                mainHeader("Core Skills")
                y = drawWrapped(data.skills, bodyPaint, rightColX, rightColWidth, y)
            }
            val validLangs = data.languages.filter { it.name.isNotBlank() }
            if (validLangs.isNotEmpty()) {
                mainHeader("Languages")
                y = drawWrapped(validLangs.joinToString(", ") { "${it.name} (${it.level})" }, bodyPaint, rightColX, rightColWidth, y)
            }
            if (data.hobbies.isNotBlank()) {
                mainHeader("Hobbies & Interests")
                y = drawWrapped(data.hobbies, bodyPaint, rightColX, rightColWidth, y)
            }
        }

        doc.finishPage(page)

        val dir = File(context.cacheDir, "resumes").apply { mkdirs() }
        val safeName = data.fullName.replace(Regex("[^A-Za-z0-9]"), "_").ifBlank { "Resume" }
        val outFile = File(dir, "${safeName}_Resume.pdf")
        FileOutputStream(outFile).use { doc.writeTo(it) }
        doc.close()
        return outFile
    }
}
