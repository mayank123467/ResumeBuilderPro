package com.resumebuilder.pro.pdf

import android.content.Context
import com.resumebuilder.pro.model.ResumeData
import com.resumebuilder.pro.model.TemplateCatalog
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ResumeExporter {
    private fun safeBaseName(data: ResumeData): String =
        data.fullName.replace(Regex("[^A-Za-z0-9]"), "_").ifBlank { "Resume" }

    fun exportTxt(context: Context, data: ResumeData): File {
        val sb = StringBuilder()
        sb.appendLine(data.fullName.ifBlank { "Your Name" })
        if (data.jobTitle.isNotBlank()) sb.appendLine(data.jobTitle)
        sb.appendLine(listOf(data.email, data.phone, data.location, data.linkedin).filter { it.isNotBlank() }.joinToString(" | "))
        sb.appendLine()
        if (data.summary.isNotBlank()) {
            sb.appendLine("PROFESSIONAL SUMMARY")
            sb.appendLine(data.summary)
            sb.appendLine()
        }
        val exp = data.experiences.filter { it.role.isNotBlank() || it.company.isNotBlank() }
        if (exp.isNotEmpty()) {
            sb.appendLine("WORK EXPERIENCE")
            exp.forEach {
                sb.appendLine("${it.role} — ${it.company} (${it.duration})")
                if (it.bullets.isNotBlank()) sb.appendLine(it.bullets)
                sb.appendLine()
            }
        }
        val proj = data.projects.filter { it.title.isNotBlank() }
        if (proj.isNotEmpty()) {
            sb.appendLine("PROJECTS")
            proj.forEach {
                sb.appendLine("${it.title} (${it.techStack})")
                if (it.description.isNotBlank()) sb.appendLine(it.description)
            }
            sb.appendLine()
        }
        val edu = data.educations.filter { it.degree.isNotBlank() || it.institution.isNotBlank() }
        if (edu.isNotEmpty()) {
            sb.appendLine("EDUCATION")
            edu.forEach { sb.appendLine("${it.degree} — ${it.institution} (${it.year})") }
            sb.appendLine()
        }
        if (data.skills.isNotBlank()) {
            sb.appendLine("CORE SKILLS")
            sb.appendLine(data.skills)
            sb.appendLine()
        }
        val langs = data.languages.filter { it.name.isNotBlank() }
        if (langs.isNotEmpty()) {
            sb.appendLine("LANGUAGES")
            sb.appendLine(langs.joinToString(", ") { "${it.name} (${it.level})" })
            sb.appendLine()
        }
        if (data.hobbies.isNotBlank()) {
            sb.appendLine("HOBBIES & INTERESTS")
            sb.appendLine(data.hobbies)
        }
        val dir = File(context.cacheDir, "resumes").apply { mkdirs() }
        val file = File(dir, "${safeBaseName(data)}_Resume.txt")
        file.writeText(sb.toString(), Charsets.UTF_8)
        return file
    }

    fun exportHtml(context: Context, data: ResumeData): File {
        val spec = TemplateCatalog.byId(data.templateId)
        val hex = String.format("#%06X", (0xFFFFFF and (data.customAccentHex ?: spec.accentHex).toInt()))
        val twoCol = !data.atsModeEnabled && spec.layout.isTwoColumn
        val html = buildString {
            append("<!DOCTYPE html><html><head><meta charset='UTF-8'><style>")
            append("body{font-family:Arial,sans-serif;margin:32px;color:#1e293b;line-height:1.5;}")
            append("h1{color:$hex;margin:0;}h2{color:$hex;border-bottom:2px solid $hex;padding-bottom:4px;font-size:15px;margin-top:18px;}")
            if (twoCol) append(".wrap{display:flex;gap:24px;}.side{width:34%;background:#f1f5f9;padding:16px;border-radius:8px;}.main{width:66%;}")
            append("</style></head><body>")
            if (twoCol) append("<div class='wrap'><div class='side'>")
            append("<h1>${data.fullName.ifBlank { "Your Name" }}</h1>")
            if (data.jobTitle.isNotBlank()) append("<p><strong>${data.jobTitle}</strong></p>")
            append("<p>${listOf(data.email, data.phone, data.location, data.linkedin).filter { it.isNotBlank() }.joinToString(" | ")}</p>")
            if (data.skills.isNotBlank()) append("<h2>Core Skills</h2><p>${data.skills}</p>")
            val langs = data.languages.filter { it.name.isNotBlank() }
            if (langs.isNotEmpty()) append("<h2>Languages</h2><p>${langs.joinToString(", ") { "${it.name} (${it.level})" }}</p>")
            if (data.hobbies.isNotBlank()) append("<h2>Hobbies</h2><p>${data.hobbies}</p>")
            if (twoCol) append("</div><div class='main'>")
            if (data.summary.isNotBlank()) append("<h2>Professional Summary</h2><p>${data.summary}</p>")
            val exp = data.experiences.filter { it.role.isNotBlank() || it.company.isNotBlank() }
            if (exp.isNotEmpty()) {
                append("<h2>Work Experience</h2>")
                exp.forEach {
                    append("<p><strong>${it.role} — ${it.company}</strong> (${it.duration})<br>${it.bullets.replace("\n", "<br>")}</p>")
                }
            }
            val proj = data.projects.filter { it.title.isNotBlank() }
            if (proj.isNotEmpty()) {
                append("<h2>Projects</h2>")
                proj.forEach { append("<p><strong>${it.title}</strong> (${it.techStack})<br>${it.description}</p>") }
            }
            val edu = data.educations.filter { it.degree.isNotBlank() || it.institution.isNotBlank() }
            if (edu.isNotEmpty()) {
                append("<h2>Education</h2>")
                edu.forEach { append("<p><strong>${it.degree}</strong> — ${it.institution} (${it.year})</p>") }
            }
            if (twoCol) append("</div></div>")
            append("</body></html>")
        }
        val dir = File(context.cacheDir, "resumes").apply { mkdirs() }
        val file = File(dir, "${safeBaseName(data)}_Resume.html")
        file.writeText(html, Charsets.UTF_8)
        return file
    }

    fun exportDoc(context: Context, data: ResumeData): File {
        val htmlFile = exportHtml(context, data)
        val dir = File(context.cacheDir, "resumes").apply { mkdirs() }
        val docFile = File(dir, "${safeBaseName(data)}_Resume.doc")
        docFile.writeText(htmlFile.readText(Charsets.UTF_8), Charsets.UTF_8)
        return docFile
    }

    fun exportDocx(context: Context, data: ResumeData): File {
        val txt = exportTxt(context, data).readText(Charsets.UTF_8)
        val escaped = txt.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        val paragraphs = escaped.lines().joinToString("") { line ->
            "<w:p><w:r><w:t>${line}</w:t></w:r></w:p>"
        }
        val docXml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>$paragraphs</w:body></w:document>"""
        val contentTypes = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>"""
        val rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""

        val dir = File(context.cacheDir, "resumes").apply { mkdirs() }
        val outFile = File(dir, "${safeBaseName(data)}_Resume.docx")
        ZipOutputStream(FileOutputStream(outFile)).use { zos ->
            zos.putNextEntry(ZipEntry("[Content_Types].xml"))
            zos.write(contentTypes.toByteArray(Charsets.UTF_8))
            zos.closeEntry()
            zos.putNextEntry(ZipEntry("_rels/.rels"))
            zos.write(rels.toByteArray(Charsets.UTF_8))
            zos.closeEntry()
            zos.putNextEntry(ZipEntry("word/document.xml"))
            zos.write(docXml.toByteArray(Charsets.UTF_8))
            zos.closeEntry()
        }
        return outFile
    }
}
