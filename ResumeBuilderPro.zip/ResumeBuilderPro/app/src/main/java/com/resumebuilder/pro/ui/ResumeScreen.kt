package com.resumebuilder.pro.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.resumebuilder.pro.model.*
import com.resumebuilder.pro.pdf.AtsPdfGenerator
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResumeScreen(viewModel: ResumeViewModel) {
    val data by viewModel.resume.collectAsState()
    val ats by viewModel.ats.collectAsState()
    val grammarIssues by viewModel.grammarIssues.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val isAiLoading by viewModel.isAiLoading.collectAsState()
    val geminiKey by viewModel.geminiKey.collectAsState()
    val userEmail by viewModel.userEmail.collectAsState()
    val userName by viewModel.userName.collectAsState()
    val isLoggedIn = !userEmail.isNullOrBlank()

    val activeTemplate = TemplateCatalog.byId(data.templateId)
    val effectiveAccent = Color(data.customAccentHex ?: activeTemplate.accentHex)
    val context = LocalContext.current
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    var tab by remember { mutableIntStateOf(0) }
    var showLoginDialog by remember { mutableStateOf(false) }
    var showAiSettings by remember { mutableStateOf(false) }
    var showFeedback by remember { mutableStateOf(false) }
    val tabs = listOf("Templates (54)", "Profile", "Experience", "Edu & Skills", "Preview & PDF")

    val filteredTemplates = remember(selectedCategory) {
        if (selectedCategory == ProfessionCategory.ALL) TemplateCatalog.all
        else TemplateCatalog.all.filter { it.category == selectedCategory }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = Color(0xFF0F172A),
                drawerContentColor = Color.White,
                modifier = Modifier.width(290.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("ResumeBuilder Pro", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(
                                text = if (isLoggedIn) "👤 $userName ($userEmail)" else "Guest Mode (3 free / profession)",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF93C5FD)
                            )
                            Spacer(Modifier.height(6.dp))
                            Button(
                                onClick = {
                                    scope.launch { drawerState.close() }
                                    if (isLoggedIn) viewModel.signOut() else showLoginDialog = true
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (isLoggedIn) "Sign Out" else "Sign Up / Google Email Login")
                            }
                        }
                    }
                    item { HorizontalDivider(color = Color(0xFF1E293B), modifier = Modifier.padding(vertical = 6.dp)) }
                    item { Text("PROFESSIONS & TEMPLATES", style = MaterialTheme.typography.labelSmall, color = Color(0xFF94A3B8)) }
                    items(ProfessionCategory.entries) { cat ->
                        NavigationDrawerItem(
                            label = { Text(cat.label) },
                            selected = selectedCategory == cat,
                            onClick = {
                                viewModel.selectCategory(cat)
                                tab = 0
                                scope.launch { drawerState.close() }
                            },
                            colors = NavigationDrawerItemDefaults.colors(
                                selectedContainerColor = Color(0xFF2563EB),
                                selectedTextColor = Color.White,
                                unselectedTextColor = Color(0xFFCBD5E1)
                            )
                        )
                    }
                    item { HorizontalDivider(color = Color(0xFF1E293B), modifier = Modifier.padding(vertical = 6.dp)) }
                    item {
                        NavigationDrawerItem(
                            label = { Text("✨ AI Settings (Gemini)") },
                            selected = false,
                            onClick = {
                                scope.launch { drawerState.close() }
                                showAiSettings = true
                            },
                            colors = NavigationDrawerItemDefaults.colors(unselectedTextColor = Color(0xFFCBD5E1))
                        )
                    }
                    item {
                        NavigationDrawerItem(
                            label = { Text("💬 Send Feedback") },
                            selected = false,
                            onClick = {
                                scope.launch { drawerState.close() }
                                showFeedback = true
                            },
                            colors = NavigationDrawerItemDefaults.colors(unselectedTextColor = Color(0xFFCBD5E1))
                        )
                    }
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF1E293B))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text("Contact Us", color = Color(0xFF38BDF8), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            Text("Mayank Parekh", color = Color.White, style = MaterialTheme.typography.bodySmall)
                            Text("mayankparekh567@gmail.com", color = Color(0xFFCBD5E1), style = MaterialTheme.typography.labelSmall)
                            TextButton(
                                onClick = {
                                    try {
                                        val mail = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:mayankparekh567@gmail.com")).apply {
                                            putExtra(Intent.EXTRA_SUBJECT, "ResumeBuilder Pro Support")
                                        }
                                        context.startActivity(mail)
                                    } catch (_: Exception) { }
                                }
                            ) {
                                Text("✉ Email Us", color = Color(0xFF93C5FD))
                            }
                        }
                    }
                }
            }
        }
    ) {
        Scaffold(
            containerColor = Color(0xFFF8FAFC),
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF0F172A),
                        titleContentColor = Color.White
                    ),
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Text("⋮", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        }
                    },
                    title = {
                        Column {
                            Text("ResumeBuilder Pro", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text("${activeTemplate.name} • ${if (isLoggedIn) "All Unlocked" else "Guest (3/cat)"}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF93C5FD))
                        }
                    },
                    actions = {
                        TextButton(onClick = { showLoginDialog = true }) {
                            Text(if (isLoggedIn) "👤 ${userName ?: "Pro"}" else "👤 Sign Up", color = Color(0xFF93C5FD))
                        }
                        Surface(
                            color = if (ats.score >= 80) Color(0xFF059669) else Color(0xFFD97706),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.padding(end = 10.dp)
                        ) {
                            Text(
                                text = "ATS ${ats.score}%",
                                color = Color.White,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                )
            }
        ) { padding ->
            Column(modifier = Modifier.fillMaxSize().padding(padding)) {
                ScrollableTabRow(selectedTabIndex = tab, edgePadding = 12.dp, containerColor = Color.White) {
                    tabs.forEachIndexed { idx, label ->
                        Tab(
                            selected = tab == idx,
                            onClick = {
                                if (idx in 1..3 && !isLoggedIn) {
                                    showLoginDialog = true
                                } else {
                                    tab = idx
                                }
                            },
                            text = { Text(label, fontWeight = FontWeight.SemiBold) }
                        )
                    }
                }

                if (isAiLoading) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    when (tab) {
                        0 -> {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(Brush.horizontalGradient(listOf(Color(0xFF1E3A8A), Color(0xFF0F766E))))
                                        .padding(16.dp)
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text("54 Modern ATS Templates", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text(
                                            if (isLoggedIn) "All 54 templates & AI editing unlocked!"
                                            else "Free preview of 3 templates per profession. Sign Up (free) to edit & unlock all 54!",
                                            color = Color(0xFFE0F2FE),
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            }
                            item {
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(ProfessionCategory.entries) { cat ->
                                        FilterChip(
                                            selected = selectedCategory == cat,
                                            onClick = { viewModel.selectCategory(cat) },
                                            label = { Text(cat.label) }
                                        )
                                    }
                                }
                            }
                            items(filteredTemplates.chunked(2)) { pair ->
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    pair.forEach { tpl ->
                                        val unlocked = viewModel.isTemplateUnlocked(tpl)
                                        TemplatePreviewCard(
                                            spec = tpl,
                                            selected = tpl.id == data.templateId,
                                            unlocked = unlocked,
                                            onClick = {
                                                if (unlocked) {
                                                    viewModel.selectTemplate(tpl.id)
                                                    Toast.makeText(context, "Selected: ${tpl.name}", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    showLoginDialog = true
                                                }
                                            },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    if (pair.size == 1) Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                        1 -> {
                            item {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilledTonalButton(onClick = { viewModel.loadSample() }) {
                                        Text("Fill Sample Resume")
                                    }
                                    Button(onClick = { viewModel.aiGenerateSummary() }) {
                                        Text("✨ AI Write Summary")
                                    }
                                }
                            }
                            if (grammarIssues.isNotEmpty()) {
                                item {
                                    GrammarSuggestionsCard(grammarIssues) {
                                        viewModel.fixAllGrammar()
                                        Toast.makeText(context, "Grammar & action verbs upgraded!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                            item { OutlinedTextField(data.fullName, { v -> viewModel.update { it.copy(fullName = v) } }, label = { Text("Full Name") }, modifier = Modifier.fillMaxWidth()) }
                            item { OutlinedTextField(data.jobTitle, { v -> viewModel.update { it.copy(jobTitle = v) } }, label = { Text("Target Job Title") }, modifier = Modifier.fillMaxWidth()) }
                            item { OutlinedTextField(data.email, { v -> viewModel.update { it.copy(email = v) } }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth()) }
                            item { OutlinedTextField(data.phone, { v -> viewModel.update { it.copy(phone = v) } }, label = { Text("Phone Number") }, modifier = Modifier.fillMaxWidth()) }
                            item { OutlinedTextField(data.location, { v -> viewModel.update { it.copy(location = v) } }, label = { Text("City, State") }, modifier = Modifier.fillMaxWidth()) }
                            item { OutlinedTextField(data.linkedin, { v -> viewModel.update { it.copy(linkedin = v) } }, label = { Text("LinkedIn / Portfolio URL") }, modifier = Modifier.fillMaxWidth()) }
                            item { OutlinedTextField(data.summary, { v -> viewModel.update { it.copy(summary = v) } }, label = { Text("Professional Summary") }, minLines = 3, modifier = Modifier.fillMaxWidth()) }
                        }
                        2 -> {
                            if (grammarIssues.isNotEmpty()) {
                                item {
                                    GrammarSuggestionsCard(grammarIssues) {
                                        viewModel.fixAllGrammar()
                                        Toast.makeText(context, "Grammar & action verbs upgraded!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                            data.experiences.forEachIndexed { idx, exp ->
                                item(key = exp.id) {
                                    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text("Experience #${idx + 1}", fontWeight = FontWeight.Bold)
                                                Row {
                                                    TextButton(onClick = { viewModel.aiUpgradeExperience(idx) }) { Text("✨ AI Polish") }
                                                    if (data.experiences.size > 1) {
                                                        TextButton(onClick = { viewModel.removeExperience(idx) }) { Text("Remove") }
                                                    }
                                                }
                                            }
                                            OutlinedTextField(exp.role, { v -> viewModel.updateExperience(idx) { it.copy(role = v) } }, label = { Text("Job Role") }, modifier = Modifier.fillMaxWidth())
                                            OutlinedTextField(exp.company, { v -> viewModel.updateExperience(idx) { it.copy(company = v) } }, label = { Text("Company Name") }, modifier = Modifier.fillMaxWidth())
                                            OutlinedTextField(exp.duration, { v -> viewModel.updateExperience(idx) { it.copy(duration = v) } }, label = { Text("Duration (e.g. 2021 - Present)") }, modifier = Modifier.fillMaxWidth())
                                            OutlinedTextField(exp.bullets, { v -> viewModel.updateExperience(idx) { it.copy(bullets = v) } }, label = { Text("Achievements (1 bullet per line)") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                                        }
                                    }
                                }
                            }
                            item {
                                Button(onClick = { viewModel.addExperience() }, modifier = Modifier.fillMaxWidth()) {
                                    Text("+ Add Another Experience")
                                }
                            }
                        }
                        3 -> {
                            data.educations.forEachIndexed { idx, edu ->
                                item(key = edu.id) {
                                    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Text("Education #${idx + 1}", fontWeight = FontWeight.Bold)
                                            OutlinedTextField(edu.degree, { v -> viewModel.updateEducation(idx) { it.copy(degree = v) } }, label = { Text("Degree / Course") }, modifier = Modifier.fillMaxWidth())
                                            OutlinedTextField(edu.institution, { v -> viewModel.updateEducation(idx) { it.copy(institution = v) } }, label = { Text("College / University") }, modifier = Modifier.fillMaxWidth())
                                            OutlinedTextField(edu.year, { v -> viewModel.updateEducation(idx) { it.copy(year = v) } }, label = { Text("Passing Year") }, modifier = Modifier.fillMaxWidth())
                                        }
                                    }
                                }
                            }
                            item {
                                OutlinedButton(onClick = { viewModel.addEducation() }, modifier = Modifier.fillMaxWidth()) {
                                    Text("+ Add Education")
                                }
                            }
                            item {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("Core Skills", fontWeight = FontWeight.Bold)
                                    FilledTonalButton(onClick = { viewModel.aiSuggestSkills() }) { Text("✨ AI Suggest Skills") }
                                }
                            }
                            item {
                                OutlinedTextField(
                                    value = data.skills,
                                    onValueChange = { v -> viewModel.update { it.copy(skills = v) } },
                                    label = { Text("Core Skills (comma-separated)") },
                                    minLines = 3,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                        4 -> {
                            item {
                                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Text("Customize Any Template", fontWeight = FontWeight.Bold)
                                        val palette = listOf(0xFF1E3A8A, 0xFF0F766E, 0xFF111827, 0xFF7C3AED, 0xFFEA580C, 0xFF991B1B)
                                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            items(palette) { hex ->
                                                val isSelected = (data.customAccentHex ?: activeTemplate.accentHex) == hex
                                                Box(
                                                    modifier = Modifier
                                                        .size(32.dp)
                                                        .clip(CircleShape)
                                                        .background(Color(hex))
                                                        .then(if (isSelected) Modifier.border(3.dp, Color.Black, CircleShape) else Modifier)
                                                        .clickable { viewModel.update { it.copy(customAccentHex = hex) } }
                                                )
                                            }
                                        }
                                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            item {
                                                FilterChip(selected = data.forceSerif == false, onClick = { viewModel.update { it.copy(forceSerif = false) } }, label = { Text("Modern Sans") })
                                            }
                                            item {
                                                FilterChip(selected = data.forceSerif == true, onClick = { viewModel.update { it.copy(forceSerif = true) } }, label = { Text("Classic Serif") })
                                            }
                                            item {
                                                FilterChip(selected = data.compactSpacing, onClick = { viewModel.update { it.copy(compactSpacing = !it.compactSpacing) } }, label = { Text("Compact Fit") })
                                            }
                                            item {
                                                FilterChip(selected = data.fontScale > 1.0f, onClick = { viewModel.update { it.copy(fontScale = if (it.fontScale > 1.0f) 1.0f else 1.1f) } }, label = { Text("Large Text") })
                                            }
                                        }
                                    }
                                }
                            }
                            if (ats.tips.isNotEmpty() || grammarIssues.isNotEmpty()) {
                                item {
                                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB))) {
                                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text("ATS & Grammar Feedback (${ats.score}/100)", fontWeight = FontWeight.Bold, color = Color(0xFF92400E))
                                            ats.tips.forEach { tip ->
                                                Text("• $tip", style = MaterialTheme.typography.bodySmall, color = Color(0xFF78350F))
                                            }
                                            grammarIssues.take(3).forEach { g ->
                                                Text("• [${g.section}] ${g.message} → ${g.suggestion}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF78350F))
                                            }
                                        }
                                    }
                                }
                            }
                            item {
                                val useSerif = data.forceSerif ?: activeTemplate.useSerif
                                val font = if (useSerif) FontFamily.Serif else FontFamily.SansSerif
                                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                    Column {
                                        if (activeTemplate.layout == TemplateLayout.EXECUTIVE_BANNER) {
                                            Column(modifier = Modifier.fillMaxWidth().background(effectiveAccent).padding(16.dp)) {
                                                Text(data.fullName.ifBlank { "Your Name" }, style = MaterialTheme.typography.headlineSmall, color = Color.White, fontWeight = FontWeight.Bold, fontFamily = font)
                                                if (data.jobTitle.isNotBlank()) Text(data.jobTitle, color = Color(0xFFE2E8F0), fontFamily = font)
                                            }
                                        }
                                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            if (activeTemplate.layout != TemplateLayout.EXECUTIVE_BANNER) {
                                                Text(data.fullName.ifBlank { "Your Name" }, style = MaterialTheme.typography.headlineSmall, color = effectiveAccent, fontWeight = FontWeight.Bold, fontFamily = font)
                                                if (data.jobTitle.isNotBlank()) Text(data.jobTitle, color = Color.DarkGray, fontFamily = font)
                                            }
                                            Text(listOf(data.email, data.phone, data.location).filter { it.isNotBlank() }.joinToString(" | "), style = MaterialTheme.typography.bodySmall, fontFamily = font)
                                            HorizontalDivider(color = effectiveAccent, modifier = Modifier.padding(vertical = 4.dp))
                                            if (data.summary.isNotBlank()) {
                                                Text("PROFESSIONAL SUMMARY", color = effectiveAccent, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium, fontFamily = font)
                                                Text(data.summary, style = MaterialTheme.typography.bodySmall, fontFamily = font)
                                            }
                                            if (data.skills.isNotBlank()) {
                                                Text("CORE SKILLS", color = effectiveAccent, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium, fontFamily = font)
                                                Text(data.skills, style = MaterialTheme.typography.bodySmall, fontFamily = font)
                                            }
                                        }
                                    }
                                }
                            }
                            item {
                                Button(
                                    onClick = {
                                        if (!isLoggedIn) {
                                            showLoginDialog = true
                                            return@Button
                                        }
                                        try {
                                            val pdf = AtsPdfGenerator.generatePdf(context, data)
                                            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", pdf)
                                            val share = Intent(Intent.ACTION_SEND).apply {
                                                type = "application/pdf"
                                                putExtra(Intent.EXTRA_STREAM, uri)
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(Intent.createChooser(share, "Save or Share ATS Resume PDF"))
                                        } catch (e: Exception) {
                                            Toast.makeText(context, "PDF Error: ${e.message}", Toast.LENGTH_LONG).show()
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth().height(52.dp)
                                ) {
                                    Text(if (isLoggedIn) "Export & Share ATS-Friendly PDF (${activeTemplate.name})" else "🔒 Sign Up Free to Export PDF")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showLoginDialog) {
        var emailInput by remember { mutableStateOf(userEmail ?: "") }
        var nameInput by remember { mutableStateOf(userName ?: "") }
        AlertDialog(
            onDismissRequest = { showLoginDialog = false },
            title = { Text(if (isLoggedIn) "👤 Account (${userName})" else "Unlock All 54 Templates & Editing") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        if (isLoggedIn) "Signed in with $userEmail. All 54 templates, AI tools, and PDF export are unlocked."
                        else "Sign up free with your Google Email to edit your resume, use AI tools, and unlock all 54 ATS templates!",
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (!isLoggedIn) {
                        OutlinedTextField(value = emailInput, onValueChange = { emailInput = it }, label = { Text("Google Email (e.g. name@gmail.com)") }, singleLine = true)
                        OutlinedTextField(value = nameInput, onValueChange = { nameInput = it }, label = { Text("Your Name") }, singleLine = true)
                    }
                }
            },
            confirmButton = {
                if (isLoggedIn) {
                    Button(onClick = {
                        viewModel.signOut()
                        showLoginDialog = false
                    }) { Text("Sign Out") }
                } else {
                    Button(onClick = {
                        if (emailInput.contains("@")) {
                            viewModel.signIn(emailInput, nameInput)
                            showLoginDialog = false
                            Toast.makeText(context, "Welcome! All 54 templates & editing unlocked.", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Please enter a valid email address", Toast.LENGTH_SHORT).show()
                        }
                    }) { Text("Sign Up / Login") }
                }
            },
            dismissButton = {
                TextButton(onClick = { showLoginDialog = false }) { Text("Close") }
            }
        )
    }

    if (showAiSettings) {
        var keyInput by remember { mutableStateOf(geminiKey) }
        AlertDialog(
            onDismissRequest = { showAiSettings = false },
            title = { Text("✨ Gemini AI Support") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Built-in offline AI & Grammar Checker work automatically. Optionally paste a free Gemini API Key for custom AI writing:", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(value = keyInput, onValueChange = { keyInput = it }, label = { Text("Gemini API Key (Optional)") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.saveGeminiKey(keyInput)
                    showAiSettings = false
                    Toast.makeText(context, "AI Settings saved!", Toast.LENGTH_SHORT).show()
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showAiSettings = false }) { Text("Close") }
            }
        )
    }

    if (showFeedback) {
        var stars by remember { mutableIntStateOf(5) }
        var note by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showFeedback = false },
            title = { Text("💬 ResumeBuilder Pro Feedback") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Rate your experience:", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (1..5).forEach { s ->
                            Text(
                                text = if (s <= stars) "★" else "☆",
                                color = Color(0xFFF59E0B),
                                style = MaterialTheme.typography.headlineSmall,
                                modifier = Modifier.clickable { stars = s }
                            )
                        }
                    }
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Your feedback or suggestion") }, minLines = 3)
                }
            },
            confirmButton = {
                Button(onClick = {
                    try {
                        val mail = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:mayankparekh567@gmail.com")).apply {
                            putExtra(Intent.EXTRA_SUBJECT, "ResumeBuilder Pro Feedback ($stars/5 Stars)")
                            putExtra(Intent.EXTRA_TEXT, note)
                        }
                        context.startActivity(mail)
                    } catch (_: Exception) {
                        Toast.makeText(context, "Thanks for your $stars/5 feedback!", Toast.LENGTH_SHORT).show()
                    }
                    showFeedback = false
                }) { Text("Send Feedback") }
            },
            dismissButton = {
                TextButton(onClick = { showFeedback = false }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun GrammarSuggestionsCard(
    issues: List<GrammarIssue>,
    onAutoFix: () -> Unit
) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF))) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Grammar & Style Suggestions (${issues.size})", fontWeight = FontWeight.Bold, color = Color(0xFF1E3A8A))
                FilledTonalButton(onClick = onAutoFix) {
                    Text("Fix Grammar")
                }
            }
            issues.take(3).forEach { issue ->
                Text("• [${issue.section}] ${issue.message} — ${issue.suggestion}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF1E40AF))
            }
        }
    }
}

@Composable
private fun TemplatePreviewCard(
    spec: ResumeTemplateSpec,
    selected: Boolean,
    unlocked: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = Color(spec.accentHex)
    val secondary = Color(spec.secondaryHex)
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .then(
                if (selected) Modifier.border(2.5.dp, accent, RoundedCornerShape(14.dp))
                else Modifier.border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(14.dp))
            )
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(82.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFF8FAFC))
                    .border(0.5.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
            ) {
                Row(modifier = Modifier.fillMaxSize()) {
                    if (spec.layout == TemplateLayout.BOLD_SIDE_STRIPE) {
                        Box(modifier = Modifier.width(6.dp).fillMaxHeight().background(accent))
                    }
                    Column(modifier = Modifier.fillMaxSize()) {
                        if (spec.layout == TemplateLayout.EXECUTIVE_BANNER) {
                            Box(modifier = Modifier.fillMaxWidth().height(24.dp).background(accent))
                        } else if (spec.layout == TemplateLayout.MODERN_ACCENT_BAR) {
                            Box(modifier = Modifier.fillMaxWidth().height(5.dp).background(accent))
                        }
                        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Box(modifier = Modifier.width(68.dp).height(6.dp).clip(RoundedCornerShape(3.dp)).background(accent))
                            Box(modifier = Modifier.width(46.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFF94A3B8)))
                            Spacer(modifier = Modifier.height(2.dp))
                            Box(modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(3.dp)).background(secondary))
                            Box(modifier = Modifier.fillMaxWidth(0.85f).height(4.dp).background(Color(0xFFCBD5E1)))
                            Box(modifier = Modifier.fillMaxWidth(0.7f).height(4.dp).background(Color(0xFFCBD5E1)))
                        }
                    }
                }
            }
            Text(
                text = spec.name,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = spec.category.label,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF64748B),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Surface(color = if (unlocked) secondary else Color(0xFFF1F5F9), shape = RoundedCornerShape(6.dp)) {
                    Text(
                        text = when {
                            selected -> "✓ Active"
                            unlocked -> "FREE"
                            else -> "🔒 Sign Up"
                        },
                        color = if (unlocked) accent else Color(0xFF64748B),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}
