package com.resumebuilder.pro.ui

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.resumebuilder.pro.model.AtsTemplate
import com.resumebuilder.pro.pdf.AtsPdfGenerator

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResumeScreen(viewModel: ResumeViewModel) {
    val data by viewModel.resume.collectAsState()
    val ats by viewModel.ats.collectAsState()
    val context = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Profile", "Experience", "Edu & Skills", "Preview & PDF")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ResumeBuilder Pro", fontWeight = FontWeight.Bold) },
                actions = {
                    Surface(
                        color = if (ats.score >= 80) Color(0xFF059669) else Color(0xFFD97706),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Text(
                            text = "ATS: ${ats.score}/100",
                            color = Color.White,
                            style = MaterialTheme.typography.labelLarge,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            ScrollableTabRow(selectedTabIndex = tab, edgePadding = 12.dp) {
                tabs.forEachIndexed { idx, label ->
                    Tab(selected = tab == idx, onClick = { tab = idx }, text = { Text(label) })
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (tab) {
                    0 -> {
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { viewModel.loadSample() }) {
                                    Text("Fill Sample Resume")
                                }
                            }
                        }
                        item { OutlinedTextField(data.fullName, { v -> viewModel.update { it.copy(fullName = v) } }, label = { Text("Full Name") }, modifier = Modifier.fillMaxWidth()) }
                        item { OutlinedTextField(data.jobTitle, { v -> viewModel.update { it.copy(jobTitle = v) } }, label = { Text("Target Job Title") }, modifier = Modifier.fillMaxWidth()) }
                        item { OutlinedTextField(data.email, { v -> viewModel.update { it.copy(email = v) } }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth()) }
                        item { OutlinedTextField(data.phone, { v -> viewModel.update { it.copy(phone = v) } }, label = { Text("Phone Number") }, modifier = Modifier.fillMaxWidth()) }
                        item { OutlinedTextField(data.location, { v -> viewModel.update { it.copy(location = v) } }, label = { Text("City, State") }, modifier = Modifier.fillMaxWidth()) }
                        item { OutlinedTextField(data.linkedin, { v -> viewModel.update { it.copy(linkedin = v) } }, label = { Text("LinkedIn / Portfolio URL") }, modifier = Modifier.fillMaxWidth()) }
                        item { OutlinedTextField(data.summary, { v -> viewModel.update { it.copy(summary = v) } }, label = { Text("Professional Summary") }, minLines = 3, modifier = Modifier.fillMaxWidth()) }
                    }
                    1 -> {
                        data.experiences.forEachIndexed { idx, exp ->
                            item(key = exp.id) {
                                Card(modifier = Modifier.fillMaxWidth()) {
                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                            Text("Experience #${idx + 1}", fontWeight = FontWeight.Bold)
                                            if (data.experiences.size > 1) {
                                                TextButton(onClick = { viewModel.removeExperience(idx) }) { Text("Remove") }
                                            }
                                        }
                                        OutlinedTextField(exp.role, { v -> viewModel.updateExperience(idx) { it.copy(role = v) } }, label = { Text("Job Role") }, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(exp.company, { v -> viewModel.updateExperience(idx) { it.copy(company = v) } }, label = { Text("Company Name") }, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(exp.duration, { v -> viewModel.updateExperience(idx) { it.copy(duration = v) } }, label = { Text("Duration (e.g. 2021 - Present)") }, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(exp.bullets, { v -> viewModel.updateExperience(idx) { it.copy(bullets = v) } }, label = { Text("Achievements (1 bullet per line with % or numbers)") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                                    }
                                }
                            }
                        }
                        item {
                            Button(onClick = { viewModel.addExperience() }, modifier = Modifier.fillMaxWidth()) {
                                Text("+ Add Another Experience")
                            }
                        }
                    }
                    2 -> {
                        data.educations.forEachIndexed { idx, edu ->
                            item(key = edu.id) {
                                Card(modifier = Modifier.fillMaxWidth()) {
                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("Education #${idx + 1}", fontWeight = FontWeight.Bold)
                                        OutlinedTextField(edu.degree, { v -> viewModel.updateEducation(idx) { it.copy(degree = v) } }, label = { Text("Degree / Course") }, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(edu.institution, { v -> viewModel.updateEducation(idx) { it.copy(institution = v) } }, label = { Text("College / University") }, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(edu.year, { v -> viewModel.updateEducation(idx) { it.copy(year = v) } }, label = { Text("Passing Year") }, modifier = Modifier.fillMaxWidth())
                                    }
                                }
                            }
                        }
                        item {
                            OutlinedButton(onClick = { viewModel.addEducation() }, modifier = Modifier.fillMaxWidth()) {
                                Text("+ Add Education")
                            }
                        }
                        item {
                            OutlinedTextField(
                                value = data.skills,
                                onValueChange = { v -> viewModel.update { it.copy(skills = v) } },
                                label = { Text("Core Skills (comma-separated)") },
                                minLines = 3,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                    3 -> {
                        item {
                            Text("Choose ATS-Friendly Template", fontWeight = FontWeight.Bold)
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                                items(AtsTemplate.entries) { tpl ->
                                    val selected = data.template == tpl
                                    FilterChip(
                                        selected = selected,
                                        onClick = { viewModel.update { it.copy(template = tpl) } },
                                        label = { Text(tpl.label) }
                                    )
                                }
                            }
                        }
                        if (ats.tips.isNotEmpty()) {
                            item {
                                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB))) {
                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("ATS Optimization Tips (${ats.score}/100)", fontWeight = FontWeight.Bold, color = Color(0xFF92400E))
                                        ats.tips.forEach { tip ->
                                            Text("• $tip", style = MaterialTheme.typography.bodySmall, color = Color(0xFF78350F))
                                        }
                                    }
                                }
                            }
                        }
                        item {
                            val accent = Color(data.template.accentHex)
                            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(data.fullName.ifBlank { "Your Name" }, style = MaterialTheme.typography.headlineSmall, color = accent, fontWeight = FontWeight.Bold)
                                    if (data.jobTitle.isNotBlank()) Text(data.jobTitle, color = Color.DarkGray)
                                    Text(listOf(data.email, data.phone, data.location).filter { it.isNotBlank() }.joinToString(" | "), style = MaterialTheme.typography.bodySmall)
                                    HorizontalDivider(color = accent, modifier = Modifier.padding(vertical = 4.dp))
                                    if (data.summary.isNotBlank()) {
                                        Text("PROFESSIONAL SUMMARY", color = accent, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                        Text(data.summary, style = MaterialTheme.typography.bodySmall)
                                    }
                                    if (data.skills.isNotBlank()) {
                                        Text("CORE SKILLS", color = accent, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                                        Text(data.skills, style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                        item {
                            Button(
                                onClick = {
                                    try {
                                        val pdf = AtsPdfGenerator.generatePdf(context, data)
                                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", pdf)
                                        val share = Intent(Intent.ACTION_SEND).apply {
                                            type = "application/pdf"
                                            putExtra(Intent.EXTRA_STREAM, uri)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(share, "Save or Share ATS Resume PDF"))
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "PDF Error: ${e.message}", Toast.LENGTH_LONG).show()
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(52.dp)
                            ) {
                                Text("Export & Share ATS-Friendly PDF")
                            }
                        }
                    }
                }
            }
        }
    }
}
