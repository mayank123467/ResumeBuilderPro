package com.resumebuilder.pro.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.resumebuilder.pro.model.*
import com.resumebuilder.pro.pdf.AtsPdfGenerator
import com.resumebuilder.pro.pdf.ResumeExporter
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResumeScreen(viewModel: ResumeViewModel) {
    val data by viewModel.resume.collectAsState()
    val ats by viewModel.ats.collectAsState()
    val grammarIssues by viewModel.grammarIssues.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val selectedColumnMode by viewModel.selectedColumnMode.collectAsState()
    val isAiLoading by viewModel.isAiLoading.collectAsState()
    val geminiKey by viewModel.geminiKey.collectAsState()
    val userEmail by viewModel.userEmail.collectAsState()
    val userName by viewModel.userName.collectAsState()
    val isLoggedIn = !userEmail.isNullOrBlank()

    val activeTemplate = TemplateCatalog.byId(data.templateId)
    val effectiveAccent = Color(data.customAccentHex ?: activeTemplate.accentHex)
    val context = LocalContext.current
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    var tab by remember { mutableIntStateOf(0) }
    var showLoginDialog by remember { mutableStateOf(false) }
    var showAiSettings by remember { mutableStateOf(false) }
    var showFeedback by remember { mutableStateOf(false) }
    val tabs = listOf("Templates (${TemplateCatalog.all.size})", "Profile", "Exp & Projects", "Edu & Extras", "Preview & PDF")

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.importResumeUri(context, uri) { ok ->
                if (ok) {
                    Toast.makeText(context, "Resume imported! Pick any template to convert.", Toast.LENGTH_LONG).show()
                    tab = 4
                } else {
                    Toast.makeText(context, "Could not read file. Try a text-based PDF or TXT.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    val filteredTemplates = remember(selectedCategory, selectedColumnMode) {
        TemplateCatalog.all.filter { tpl ->
            val catOk = selectedCategory == ProfessionCategory.ALL || tpl.category == selectedCategory
            val colOk = when (selectedColumnMode) {
                TemplateColumnMode.ALL -> true
                TemplateColumnMode.TWO_COLUMN -> tpl.layout.isTwoColumn
                TemplateColumnMode.SINGLE_COLUMN -> !tpl.layout.isTwoColumn
                TemplateColumnMode.CANVA_MODERN -> tpl.layout.isCanvaStyle
            }
            catOk && colOk
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = Color(0xFF0F172A),
                drawerContentColor = Color.White,
                modifier = Modifier.width(290.dp)
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("ResumeBuilder Pro", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(
                                text = if (isLoggedIn) "👤 $userName ($userEmail)" else "Guest Mode (3 free / profession)",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF93C5FD)
                            )
                            Spacer(Modifier.height(6.dp))
                            Button(
                                onClick = {
                                    scope.launch { drawerState.close() }
                                    if (isLoggedIn) viewModel.signOut() else showLoginDialog = true
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (isLoggedIn) "Sign Out" else "Sign Up / Google Email Login")
                            }
                        }
                    }
                    item { HorizontalDivider(color = Color(0xFF1E293B), modifier = Modifier.padding(vertical = 6.dp)) }
                    item { Text("PROFESSIONS & TEMPLATES", style = MaterialTheme.typography.labelSmall, color = Color(0xFF94A3B8)) }
                    items(ProfessionCategory.entries) { cat ->
                        NavigationDrawerItem(
                            label = { Text(cat.label) },
                            selected = selectedCategory == cat,
                            onClick = {
                                viewModel.selectCategory(cat)
                                tab = 0
                                scope.launch { drawerState.close() }
                            },
                            colors = NavigationDrawerItemDefaults.colors(
                                selectedContainerColor = Color(0xFF2563EB),
                                selectedTextColor = Color.White,
                                unselectedTextColor = Color(0xFFCBD5E1)
                            )
                        )
                    }
                    item { HorizontalDivider(color = Color(0xFF1E293B), modifier = Modifier.padding(vertical = 6.dp)) }
                    item {
                        NavigationDrawerItem(
                            label = { Text("📄 Import Resume (PDF/DOCX/HTML/TXT)") },
                            selected = false,
                            onClick = {
                                scope.launch { drawerState.close() }
                                if (isLoggedIn) importLauncher.launch(arrayOf("application/pdf", "text/plain", "text/html", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "*/*"))
                                else showLoginDialog = true
                            },
                            colors = NavigationDrawerItemDefaults.colors(unselectedTextColor = Color(0xFFCBD5E1))
                        )
                    }
                    item {
                        NavigationDrawerItem(
                            label = { Text("✨ AI Settings (Gemini)") },
                            selected = false,
                            onClick = {
                                scope.launch { drawerState.close() }
                                showAiSettings = true
                            },
                            colors = NavigationDrawerItemDefaults.colors(unselectedTextColor = Color(0xFFCBD5E1))
                        )
                    }
                    item {
                        NavigationDrawerItem(
                            label = { Text("💬 Send Feedback") },
                            selected = false,
                            onClick = {
                                scope.launch { drawerState.close() }
                                showFeedback = true
                            },
                            colors = NavigationDrawerItemDefaults.colors(unselectedTextColor = Color(0xFFCBD5E1))
                        )
                    }
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF1E293B))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text("Contact Us", color = Color(0xFF38BDF8), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            Text("Mayank Parekh", color = Color.White, style = MaterialTheme.typography.bodySmall)
                            Text("mayankparekh567@gmail.com", color = Color(0xFFCBD5E1), style = MaterialTheme.typography.labelSmall)
                            TextButton(
                                onClick = {
                                    try {
                                        val mail = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:mayankparekh567@gmail.com")).apply {
                                            putExtra(Intent.EXTRA_SUBJECT, "ResumeBuilder Pro Support")
                                        }
                                        context.startActivity(mail)
                                    } catch (_: Exception) { }
                                }
                            ) {
                                Text("✉ Email Us", color = Color(0xFF93C5FD))
                            }
                        }
                    }
                }
            }
        }
    ) {
        Scaffold(
            containerColor = Color(0xFFF8FAFC),
            topBar = {
                TopAppBar(
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color(0xFF0F172A),
                        titleContentColor = Color.White
                    ),
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Text("⋮", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        }
                    },
                    title = {
                        Column {
                            Text("ResumeBuilder Pro", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text("${activeTemplate.name} • ${if (activeTemplate.layout.isTwoColumn) "2-Col" else "1-Col"}", style = MaterialTheme.typography.labelSmall, color = Color(0xFF93C5FD))
                        }
                    },
                    actions = {
                        TextButton(onClick = { showLoginDialog = true }) {
                            Text(if (isLoggedIn) "👤 ${userName ?: "Pro"}" else "👤 Sign Up", color = Color(0xFF93C5FD))
                        }
                        Surface(
                            color = if (ats.score >= 80) Color(0xFF059669) else Color(0xFFD97706),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.padding(end = 10.dp)
                        ) {
                            Text(
                                text = "ATS ${ats.score}%",
                                color = Color.White,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                )
            }
        ) { padding ->
            Column(modifier = Modifier.fillMaxSize().padding(padding)) {
                ScrollableTabRow(selectedTabIndex = tab, edgePadding = 12.dp, containerColor = Color.White) {
                    tabs.forEachIndexed { idx, label ->
                        Tab(
                            selected = tab == idx,
                            onClick = {
                                if (idx in 1..3 && !isLoggedIn) {
                                    showLoginDialog = true
                                } else {
                                    tab = idx
                                }
                            },
                            text = { Text(label, fontWeight = FontWeight.SemiBold) }
                        )
                    }
                }

                if (isAiLoading) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    when (tab) {
                        0 -> {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(Brush.horizontalGradient(listOf(Color(0xFF1E3A8A), Color(0xFF0F766E))))
                                        .padding(16.dp)
                                ) {
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("${TemplateCatalog.all.size} Canva & ATS Templates", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text(
                                            if (isLoggedIn) "Upload your existing resume or pick any 2-Column / Single-Column template!"
                                            else "Free preview of 3 templates per profession. Sign Up (free) to edit, import & unlock all ${TemplateCatalog.all.size}!",
                                            color = Color(0xFFE0F2FE),
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                        FilledTonalButton(onClick = {
                                            if (isLoggedIn) importLauncher.launch(arrayOf("application/pdf", "text/plain", "text/html", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "*/*"))
                                            else showLoginDialog = true
                                        }) {
                                            Text("📄 Upload & Convert Existing Resume (PDF/DOCX/HTML/TXT)")
                                        }
                                    }
                                }
                            }
                            item {
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(TemplateColumnMode.entries) { mode ->
                                        FilterChip(
                                            selected = selectedColumnMode == mode,
                                            onClick = { viewModel.selectColumnMode(mode) },
                                            label = { Text(mode.label) }
                                        )
                                    }
                                }
                            }
                            item {
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(ProfessionCategory.entries) { cat ->
                                        FilterChip(
                                            selected = selectedCategory == cat,
                                            onClick = { viewModel.selectCategory(cat) },
                                            label = { Text(cat.label) }
                                        )
                                    }
                                }
                            }
                            items(filteredTemplates.chunked(2)) { pair ->
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    pair.forEach { tpl ->
                                        val unlocked = viewModel.isTemplateUnlocked(tpl)
                                        TemplatePreviewCard(
                                            spec = tpl,
                                            selected = tpl.id == data.templateId,
                                            unlocked = unlocked,
                                            onClick = {
                                                if (unlocked) {
                                                    viewModel.selectTemplate(tpl.id)
                                                    Toast.makeText(context, "Selected: ${tpl.name}", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    showLoginDialog = true
                                                }
                                            },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    if (pair.size == 1) Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                        1 -> {
                            item {
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    item {
                                        FilledTonalButton(onClick = { viewModel.loadSample() }) { Text("Fill Sample") }
                                    }
                                    item {
                                        FilledTonalButton(onClick = { importLauncher.launch(arrayOf("application/pdf", "text/plain", "text/html", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "*/*")) }) { Text("📄 Import File") }
                                    }
                                    item {
                                        Button(onClick = { viewModel.aiGenerateSummary() }) { Text("✨ AI Summary") }
                                    }
                                }
                            }
                            if (grammarIssues.isNotEmpty()) {
                                item {
                                    GrammarSuggestionsCard(grammarIssues) {
                                        viewModel.fixAllGrammar()
                                        Toast.makeText(context, "Grammar & action verbs upgraded!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                            item { OutlinedTextField(data.fullName, { v -> viewModel.update { it.copy(fullName = v) } }, label = { Text("Full Name") }, modifier = Modifier.fillMaxWidth()) }
                            item { OutlinedTextField(data.jobTitle, { v -> viewModel.update { it.copy(jobTitle = v) } }, label = { Text("Target Job Title") }, modifier = Modifier.fillMaxWidth()) }
                            item { OutlinedTextField(data.email, { v -> viewModel.update { it.copy(email = v) } }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth()) }
                            item { OutlinedTextField(data.phone, { v -> viewModel.update { it.copy(phone = v) } }, label = { Text("Phone Number") }, modifier = Modifier.fillMaxWidth()) }
                            item { OutlinedTextField(data.location, { v -> viewModel.update { it.copy(location = v) } }, label = { Text("City, State") }, modifier = Modifier.fillMaxWidth()) }
                            item { OutlinedTextField(data.linkedin, { v -> viewModel.update { it.copy(linkedin = v) } }, label = { Text("LinkedIn / Portfolio URL") }, modifier = Modifier.fillMaxWidth()) }
                            item { OutlinedTextField(data.summary, { v -> viewModel.update { it.copy(summary = v) } }, label = { Text("Professional Summary") }, minLines = 3, modifier = Modifier.fillMaxWidth()) }
                        }
                        2 -> {
                            if (grammarIssues.isNotEmpty()) {
                                item {
                                    GrammarSuggestionsCard(grammarIssues) {
                                        viewModel.fixAllGrammar()
                                        Toast.makeText(context, "Grammar & action verbs upgraded!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                            item {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("Work Experience", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    FilledTonalButton(onClick = { viewModel.addExperience() }) { Text("+ Add") }
                                }
                            }
                            data.experiences.forEachIndexed { idx, exp ->
                                item(key = exp.id) {
                                    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text("Experience #${idx + 1}", fontWeight = FontWeight.Bold)
                                                Row {
                                                    TextButton(onClick = { viewModel.aiUpgradeExperience(idx) }) { Text("✨ AI Polish") }
                                                    if (data.experiences.size > 1) {
                                                        TextButton(onClick = { viewModel.removeExperience(idx) }) { Text("Remove") }
                                                    }
                                                }
                                            }
                                            OutlinedTextField(exp.role, { v -> viewModel.updateExperience(idx) { it.copy(role = v) } }, label = { Text("Job Role") }, modifier = Modifier.fillMaxWidth())
                                            OutlinedTextField(exp.company, { v -> viewModel.updateExperience(idx) { it.copy(company = v) } }, label = { Text("Company Name") }, modifier = Modifier.fillMaxWidth())
                                            OutlinedTextField(exp.duration, { v -> viewModel.updateExperience(idx) { it.copy(duration = v) } }, label = { Text("Duration (e.g. 2021 - Present)") }, modifier = Modifier.fillMaxWidth())
                                            OutlinedTextField(exp.bullets, { v -> viewModel.updateExperience(idx) { it.copy(bullets = v) } }, label = { Text("Achievements (1 bullet per line)") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                                        }
                                    }
                                }
                            }
                            item {
                                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("Projects", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    FilledTonalButton(onClick = { viewModel.addProject() }) { Text("+ Add") }
                                }
                            }
                            data.projects.forEachIndexed { idx, proj ->
                                item(key = proj.id) {
                                    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text("Project #${idx + 1}", fontWeight = FontWeight.Bold)
                                                if (data.projects.size > 1) {
                                                    TextButton(onClick = { viewModel.removeProject(idx) }) { Text("Remove") }
                                                }
                                            }
                                            OutlinedTextField(proj.title, { v -> viewModel.updateProject(idx) { it.copy(title = v) } }, label = { Text("Project Title") }, modifier = Modifier.fillMaxWidth())
                                            OutlinedTextField(proj.techStack, { v -> viewModel.updateProject(idx) { it.copy(techStack = v) } }, label = { Text("Tools / Tech / Role") }, modifier = Modifier.fillMaxWidth())
                                            OutlinedTextField(proj.description, { v -> viewModel.updateProject(idx) { it.copy(description = v) } }, label = { Text("Project Impact / Description") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                                        }
                                    }
                                }
                            }
                        }
                        3 -> {
                            item {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("Education", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    FilledTonalButton(onClick = { viewModel.addEducation() }) { Text("+ Add") }
                                }
                            }
                            data.educations.forEachIndexed { idx, edu ->
                                item(key = edu.id) {
                                    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text("Education #${idx + 1}", fontWeight = FontWeight.Bold)
                                                if (data.educations.size > 1) {
                                                    TextButton(onClick = { viewModel.removeEducation(idx) }) { Text("Remove") }
                                                }
                                            }
                                            OutlinedTextField(edu.degree, { v -> viewModel.updateEducation(idx) { it.copy(degree = v) } }, label = { Text("Degree / Course") }, modifier = Modifier.fillMaxWidth())
                                            OutlinedTextField(edu.institution, { v -> viewModel.updateEducation(idx) { it.copy(institution = v) } }, label = { Text("College / University") }, modifier = Modifier.fillMaxWidth())
                                            OutlinedTextField(edu.year, { v -> viewModel.updateEducation(idx) { it.copy(year = v) } }, label = { Text("Passing Year") }, modifier = Modifier.fillMaxWidth())
                                        }
                                    }
                                }
                            }
                            item {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("Core Skills", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    FilledTonalButton(onClick = { viewModel.aiSuggestSkills() }) { Text("✨ AI Suggest") }
                                }
                            }
                            item {
                                OutlinedTextField(
                                    value = data.skills,
                                    onValueChange = { v -> viewModel.update { it.copy(skills = v) } },
                                    label = { Text("Core Skills (comma-separated)") },
                                    minLines = 2,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            item {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("Languages", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    FilledTonalButton(onClick = { viewModel.addLanguage() }) { Text("+ Add") }
                                }
                            }
                            data.languages.forEachIndexed { idx, lang ->
                                item(key = lang.id) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        OutlinedTextField(lang.name, { v -> viewModel.updateLanguage(idx) { it.copy(name = v) } }, label = { Text("Language") }, modifier = Modifier.weight(1f))
                                        OutlinedTextField(lang.level, { v -> viewModel.updateLanguage(idx) { it.copy(level = v) } }, label = { Text("Level") }, modifier = Modifier.weight(0.8f))
                                        if (data.languages.size > 1) {
                                            TextButton(onClick = { viewModel.removeLanguage(idx) }) { Text("✕") }
                                        }
                                    }
                                }
                            }
                            item {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("Achievements & Awards", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    FilledTonalButton(onClick = { viewModel.addAchievement() }) { Text("+ Add") }
                                }
                            }
                            data.achievements.forEachIndexed { idx, ach ->
                                item(key = ach.id) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        OutlinedTextField(ach.title, { v -> viewModel.updateAchievement(idx) { it.copy(title = v) } }, label = { Text("Award / Certification") }, modifier = Modifier.weight(1f))
                                        OutlinedTextField(ach.year, { v -> viewModel.updateAchievement(idx) { it.copy(year = v) } }, label = { Text("Year") }, modifier = Modifier.weight(0.45f))
                                        if (data.achievements.size > 1) {
                                            TextButton(onClick = { viewModel.removeAchievement(idx) }) { Text("✕") }
                                        }
                                    }
                                }
                            }
                            item {
                                OutlinedTextField(
                                    value = data.hobbies,
                                    onValueChange = { v -> viewModel.update { it.copy(hobbies = v) } },
                                    label = { Text("Hobbies & Interests (comma-separated)") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                        4 -> {
                            item {
                                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text("ATS Mode: ${if (data.atsModeEnabled) "ON (Bot-Friendly 1-Col)" else "OFF (Visual 2-Col / Designer)"}", fontWeight = FontWeight.Bold)
                                                Text("Toggle to see ATS vs Visual Designer difference", style = MaterialTheme.typography.labelSmall, color = Color(0xFF64748B))
                                            }
                                            Switch(
                                                checked = data.atsModeEnabled,
                                                onCheckedChange = { on -> viewModel.update { it.copy(atsModeEnabled = on) } }
                                            )
                                        }
                                        HorizontalDivider()
                                        Text("Customize Template Style", fontWeight = FontWeight.Bold)
                                        val palette = listOf(0xFF1E3A8A, 0xFF0F766E, 0xFF111827, 0xFF7C3AED, 0xFFEA580C, 0xFF991B1B)
                                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            items(palette) { hex ->
                                                val isSelected = (data.customAccentHex ?: activeTemplate.accentHex) == hex
                                                Box(
                                                    modifier = Modifier
                                                        .size(32.dp)
                                                        .clip(CircleShape)
                                                        .background(Color(hex))
                                                        .then(if (isSelected) Modifier.border(3.dp, Color.Black, CircleShape) else Modifier)
                                                        .clickable { viewModel.update { it.copy(customAccentHex = hex) } }
                                                )
                                            }
                                        }
                                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            item { FilterChip(selected = data.forceSerif == false, onClick = { viewModel.update { it.copy(forceSerif = false) } }, label = { Text("Modern Sans") }) }
                                            item { FilterChip(selected = data.forceSerif == true, onClick = { viewModel.update { it.copy(forceSerif = true) } }, label = { Text("Classic Serif") }) }
                                            item { FilterChip(selected = data.compactSpacing, onClick = { viewModel.update { it.copy(compactSpacing = !it.compactSpacing) } }, label = { Text("Compact Fit") }) }
                                            item { FilterChip(selected = data.fontScale > 1.0f, onClick = { viewModel.update { it.copy(fontScale = if (it.fontScale > 1.0f) 1.0f else 1.1f) } }, label = { Text("Large Text") }) }
                                        }
                                    }
                                }
                            }
                            if (ats.tips.isNotEmpty() || grammarIssues.isNotEmpty()) {
                                item {
                                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFBEB))) {
                                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            Text("ATS & Grammar Feedback (${ats.score}/100)", fontWeight = FontWeight.Bold, color = Color(0xFF92400E))
                                            ats.tips.forEach { tip ->
                                                Text("• $tip", style = MaterialTheme.typography.bodySmall, color = Color(0xFF78350F))
                                            }
                                            grammarIssues.take(3).forEach { g ->
                                                Text("• [${g.section}] ${g.message} → ${g.suggestion}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF78350F))
                                            }
                                        }
                                    }
                                }
                            }
                            item {
                                val useSerif = data.forceSerif ?: activeTemplate.useSerif
                                val font = if (useSerif) FontFamily.Serif else FontFamily.SansSerif
                                val bannerTint = Color(activeTemplate.secondaryHex)
                                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                                    if (!data.atsModeEnabled && activeTemplate.layout.isTwoColumn) {
                                        val isDark = activeTemplate.layout == TemplateLayout.TWO_COL_DARK_SIDEBAR
                                        val sideBg = if (isDark) Color(0xFF0F172A) else bannerTint
                                        val sideTxt = if (isDark) Color.White else Color(0xFF1E293B)
                                        Column {
                                            if (activeTemplate.layout == TemplateLayout.TWO_COL_CANVA_BOLD) {
                                                Column(modifier = Modifier.fillMaxWidth().background(effectiveAccent).padding(16.dp)) {
                                                    Text(data.fullName.ifBlank { "Your Name" }, style = MaterialTheme.typography.headlineSmall, color = Color.White, fontWeight = FontWeight.Bold, fontFamily = font)
                                                    if (data.jobTitle.isNotBlank()) Text(data.jobTitle, color = Color(0xFFE2E8F0), fontFamily = font)
                                                }
                                            }
                                            Row(modifier = Modifier.fillMaxWidth()) {
                                                Column(
                                                    modifier = Modifier.weight(0.38f).background(sideBg).padding(12.dp),
                                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    if (activeTemplate.layout != TemplateLayout.TWO_COL_CANVA_BOLD) {
                                                        Text(data.fullName.ifBlank { "Your Name" }, style = MaterialTheme.typography.titleMedium, color = if (isDark) Color.White else effectiveAccent, fontWeight = FontWeight.Bold, fontFamily = font)
                                                        if (data.jobTitle.isNotBlank()) Text(data.jobTitle, style = MaterialTheme.typography.labelSmall, color = sideTxt, fontFamily = font)
                                                        HorizontalDivider(color = effectiveAccent)
                                                    }
                                                    SectionBanner("CONTACT", if (isDark) Color(0xFF1E293B) else Color.White.copy(alpha = 0.6f), if (isDark) Color(0xFF93C5FD) else effectiveAccent, font)
                                                    listOf(data.email, data.phone, data.location, data.linkedin).filter { it.isNotBlank() }.forEach {
                                                        Text(it, style = MaterialTheme.typography.labelSmall, color = sideTxt)
                                                    }
                                                    SectionBanner("SKILLS", if (isDark) Color(0xFF1E293B) else Color.White.copy(alpha = 0.6f), if (isDark) Color(0xFF93C5FD) else effectiveAccent, font)
                                                    Text(data.skills.ifBlank { "Add skills" }, style = MaterialTheme.typography.labelSmall, color = sideTxt)
                                                    SectionBanner("LANGUAGES", if (isDark) Color(0xFF1E293B) else Color.White.copy(alpha = 0.6f), if (isDark) Color(0xFF93C5FD) else effectiveAccent, font)
                                                    Text(data.languages.filter { it.name.isNotBlank() }.joinToString(", ") { "${it.name} (${it.level})" }, style = MaterialTheme.typography.labelSmall, color = sideTxt)
                                                    if (data.hobbies.isNotBlank()) {
                                                        SectionBanner("HOBBIES", if (isDark) Color(0xFF1E293B) else Color.White.copy(alpha = 0.6f), if (isDark) Color(0xFF93C5FD) else effectiveAccent, font)
                                                        Text(data.hobbies, style = MaterialTheme.typography.labelSmall, color = sideTxt)
                                                    }
                                                }
                                                Column(
                                                    modifier = Modifier.weight(0.62f).padding(12.dp),
                                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    if (data.summary.isNotBlank()) {
                                                        SectionBanner("SUMMARY", bannerTint, effectiveAccent, font)
                                                        Text(data.summary, style = MaterialTheme.typography.bodySmall, fontFamily = font)
                                                    }
                                                    SectionBanner("WORK EXPERIENCE", bannerTint, effectiveAccent, font)
                                                    data.experiences.filter { it.role.isNotBlank() || it.company.isNotBlank() }.forEach { e ->
                                                        Text("${e.role} — ${e.company} (${e.duration})", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, fontFamily = font)
                                                        if (e.bullets.isNotBlank()) Text(e.bullets, style = MaterialTheme.typography.bodySmall, fontFamily = font)
                                                    }
                                                    if (data.projects.any { it.title.isNotBlank() }) {
                                                        SectionBanner("PROJECTS", bannerTint, effectiveAccent, font)
                                                        data.projects.filter { it.title.isNotBlank() }.forEach { p ->
                                                            Text("${p.title} (${p.techStack})", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                                            if (p.description.isNotBlank()) Text(p.description, style = MaterialTheme.typography.bodySmall)
                                                        }
                                                    }
                                                    if (data.educations.any { it.degree.isNotBlank() }) {
                                                        SectionBanner("EDUCATION", bannerTint, effectiveAccent, font)
                                                        data.educations.filter { it.degree.isNotBlank() }.forEach { ed ->
                                                            Text("${ed.degree} — ${ed.institution} (${ed.year})", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                                        }
                                                    }
                                                    if (data.achievements.any { it.title.isNotBlank() }) {
                                                        SectionBanner("ACHIEVEMENTS", bannerTint, effectiveAccent, font)
                                                        data.achievements.filter { it.title.isNotBlank() }.forEach { a ->
                                                            Text("• ${a.title} ${if (a.year.isNotBlank()) "(${a.year})" else ""}", style = MaterialTheme.typography.bodySmall)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    } else {
                                        Column {
                                            if (activeTemplate.layout == TemplateLayout.EXECUTIVE_BANNER) {
                                                Column(modifier = Modifier.fillMaxWidth().background(effectiveAccent).padding(16.dp)) {
                                                    Text(data.fullName.ifBlank { "Your Name" }, style = MaterialTheme.typography.headlineSmall, color = Color.White, fontWeight = FontWeight.Bold, fontFamily = font)
                                                    if (data.jobTitle.isNotBlank()) Text(data.jobTitle, color = Color(0xFFE2E8F0), fontFamily = font)
                                                }
                                            }
                                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                                if (activeTemplate.layout != TemplateLayout.EXECUTIVE_BANNER) {
                                                    Text(data.fullName.ifBlank { "Your Name" }, style = MaterialTheme.typography.headlineSmall, color = effectiveAccent, fontWeight = FontWeight.Bold, fontFamily = font)
                                                    if (data.jobTitle.isNotBlank()) Text(data.jobTitle, color = Color.DarkGray, fontFamily = font)
                                                }
                                                Text(listOf(data.email, data.phone, data.location, data.linkedin).filter { it.isNotBlank() }.joinToString(" | "), style = MaterialTheme.typography.bodySmall, fontFamily = font)
                                                HorizontalDivider(color = effectiveAccent, modifier = Modifier.padding(vertical = 2.dp))
                                                if (data.summary.isNotBlank()) {
                                                    SectionBanner("PROFESSIONAL SUMMARY", bannerTint, effectiveAccent, font)
                                                    Text(data.summary, style = MaterialTheme.typography.bodySmall, fontFamily = font)
                                                }
                                                if (data.experiences.any { it.role.isNotBlank() }) {
                                                    SectionBanner("WORK EXPERIENCE", bannerTint, effectiveAccent, font)
                                                    data.experiences.filter { it.role.isNotBlank() }.forEach { e ->
                                                        Text("${e.role} — ${e.company} (${e.duration})", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, fontFamily = font)
                                                        if (e.bullets.isNotBlank()) Text(e.bullets, style = MaterialTheme.typography.bodySmall, fontFamily = font)
                                                    }
                                                }
                                                if (data.projects.any { it.title.isNotBlank() }) {
                                                    SectionBanner("PROJECTS", bannerTint, effectiveAccent, font)
                                                    data.projects.filter { it.title.isNotBlank() }.forEach { p ->
                                                        Text("${p.title} (${p.techStack})", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                                        if (p.description.isNotBlank()) Text(p.description, style = MaterialTheme.typography.bodySmall)
                                                    }
                                                }
                                                if (data.educations.any { it.degree.isNotBlank() }) {
                                                    SectionBanner("EDUCATION", bannerTint, effectiveAccent, font)
                                                    data.educations.filter { it.degree.isNotBlank() }.forEach { ed ->
                                                        Text("${ed.degree} — ${ed.institution} (${ed.year})", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                                                    }
                                                }
                                                if (data.skills.isNotBlank()) {
                                                    SectionBanner("CORE SKILLS", bannerTint, effectiveAccent, font)
                                                    Text(data.skills, style = MaterialTheme.typography.bodySmall, fontFamily = font)
                                                }
                                                if (data.languages.any { it.name.isNotBlank() }) {
                                                    SectionBanner("LANGUAGES", bannerTint, effectiveAccent, font)
                                                    Text(data.languages.filter { it.name.isNotBlank() }.joinToString(", ") { "${it.name} (${it.level})" }, style = MaterialTheme.typography.bodySmall)
                                                }
                                                if (data.hobbies.isNotBlank()) {
                                                    SectionBanner("HOBBIES & INTERESTS", bannerTint, effectiveAccent, font)
                                                    Text(data.hobbies, style = MaterialTheme.typography.bodySmall)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            item {
                                fun shareExport(file: java.io.File, mime: String) {
                                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                    val share = Intent(Intent.ACTION_SEND).apply {
                                        type = mime
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(share, "Save or Share ${file.extension.uppercase()}"))
                                }
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        if (isLoggedIn) "Export Resume (All Formats)" else "🔒 Sign Up Free to Export",
                                        fontWeight = FontWeight.Bold
                                    )
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        val formats = listOf(
                                            "PDF" to "application/pdf",
                                            "DOCX" to "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                                            "HTML" to "text/html",
                                            "TXT" to "text/plain",
                                            "DOC" to "application/msword"
                                        )
                                        items(formats) { (fmt, mime) ->
                                            Button(onClick = {
                                                if (!isLoggedIn) {
                                                    showLoginDialog = true
                                                    return@Button
                                                }
                                                try {
                                                    val f = when (fmt) {
                                                        "PDF" -> AtsPdfGenerator.generatePdf(context, data)
                                                        "DOCX" -> ResumeExporter.exportDocx(context, data)
                                                        "HTML" -> ResumeExporter.exportHtml(context, data)
                                                        "DOC" -> ResumeExporter.exportDoc(context, data)
                                                        else -> ResumeExporter.exportTxt(context, data)
                                                    }
                                                    shareExport(f, mime)
                                                } catch (e: Exception) {
                                                    Toast.makeText(context, "$fmt Error: ${e.message}", Toast.LENGTH_LONG).show()
                                                }
                                            }) {
                                                Text(fmt)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showLoginDialog) {
        var emailInput by remember { mutableStateOf(userEmail ?: "") }
        var nameInput by remember { mutableStateOf(userName ?: "") }
        AlertDialog(
            onDismissRequest = { showLoginDialog = false },
            title = { Text(if (isLoggedIn) "👤 Account ($userName)" else "Unlock All ${TemplateCatalog.all.size} Templates & Editing") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        if (isLoggedIn) "Signed in with $userEmail. All templates, editing, import & PDF export are unlocked."
                        else "Sign up free with your Google Email to edit your resume, import PDF/TXT, and unlock all ${TemplateCatalog.all.size} templates!",
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (!isLoggedIn) {
                        OutlinedTextField(value = emailInput, onValueChange = { emailInput = it }, label = { Text("Google Email (e.g. name@gmail.com)") }, singleLine = true)
                        OutlinedTextField(value = nameInput, onValueChange = { nameInput = it }, label = { Text("Your Name") }, singleLine = true)
                    }
                }
            },
            confirmButton = {
                if (isLoggedIn) {
                    Button(onClick = { viewModel.signOut(); showLoginDialog = false }) { Text("Sign Out") }
                } else {
                    Button(onClick = {
                        if (emailInput.contains("@")) {
                            viewModel.signIn(emailInput, nameInput)
                            showLoginDialog = false
                            Toast.makeText(context, "Welcome! All templates & editing unlocked.", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Please enter a valid email address", Toast.LENGTH_SHORT).show()
                        }
                    }) { Text("Sign Up / Login") }
                }
            },
            dismissButton = { TextButton(onClick = { showLoginDialog = false }) { Text("Close") } }
        )
    }

    if (showAiSettings) {
        var keyInput by remember { mutableStateOf(geminiKey) }
        AlertDialog(
            onDismissRequest = { showAiSettings = false },
            title = { Text("✨ Gemini AI Support") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Built-in offline AI & Grammar Checker work automatically. Optionally paste a free Gemini API Key for custom AI writing:", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(value = keyInput, onValueChange = { keyInput = it }, label = { Text("Gemini API Key (Optional)") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    viewModel.saveGeminiKey(keyInput)
                    showAiSettings = false
                    Toast.makeText(context, "AI Settings saved!", Toast.LENGTH_SHORT).show()
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showAiSettings = false }) { Text("Close") } }
        )
    }

    if (showFeedback) {
        var stars by remember { mutableIntStateOf(5) }
        var note by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showFeedback = false },
            title = { Text("💬 ResumeBuilder Pro Feedback") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Rate your experience:", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        (1..5).forEach { s ->
                            Text(
                                text = if (s <= stars) "★" else "☆",
                                color = Color(0xFFF59E0B),
                                style = MaterialTheme.typography.headlineSmall,
                                modifier = Modifier.clickable { stars = s }
                            )
                        }
                    }
                    OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("Your feedback or suggestion") }, minLines = 3)
                }
            },
            confirmButton = {
                Button(onClick = {
                    try {
                        val mail = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:mayankparekh567@gmail.com")).apply {
                            putExtra(Intent.EXTRA_SUBJECT, "ResumeBuilder Pro Feedback ($stars/5 Stars)")
                            putExtra(Intent.EXTRA_TEXT, note)
                        }
                        context.startActivity(mail)
                    } catch (_: Exception) {
                        Toast.makeText(context, "Thanks for your $stars/5 feedback!", Toast.LENGTH_SHORT).show()
                    }
                    showFeedback = false
                }) { Text("Send Feedback") }
            },
            dismissButton = { TextButton(onClick = { showFeedback = false }) { Text("Close") } }
        )
    }
}

@Composable
private fun GrammarSuggestionsCard(
    issues: List<GrammarIssue>,
    onAutoFix: () -> Unit
) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF))) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Grammar & Style Suggestions (${issues.size})", fontWeight = FontWeight.Bold, color = Color(0xFF1E3A8A))
                FilledTonalButton(onClick = onAutoFix) { Text("Fix Grammar") }
            }
            issues.take(3).forEach { issue ->
                Text("• [${issue.section}] ${issue.message} — ${issue.suggestion}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF1E40AF))
            }
        }
    }
}

@Composable
private fun TemplatePreviewCard(
    spec: ResumeTemplateSpec,
    selected: Boolean,
    unlocked: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = Color(spec.accentHex)
    val secondary = Color(spec.secondaryHex)
    val isDarkSidebar = spec.layout == TemplateLayout.TWO_COL_DARK_SIDEBAR
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .then(
                if (selected) Modifier.border(2.5.dp, accent, RoundedCornerShape(14.dp))
                else Modifier.border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(14.dp))
            )
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(86.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFF8FAFC))
                    .border(0.5.dp, Color(0xFFE2E8F0), RoundedCornerShape(8.dp))
            ) {
                if (spec.layout.isTwoColumn) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        if (spec.layout == TemplateLayout.TWO_COL_CANVA_BOLD) {
                            Box(modifier = Modifier.fillMaxWidth().height(18.dp).background(accent))
                        }
                        Row(modifier = Modifier.fillMaxSize()) {
                            Box(
                                modifier = Modifier
                                    .width(42.dp)
                                    .fillMaxHeight()
                                    .background(if (isDarkSidebar) Color(0xFF0F172A) else secondary)
                                    .padding(5.dp)
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Box(modifier = Modifier.size(14.dp).clip(CircleShape).background(accent))
                                    Box(modifier = Modifier.fillMaxWidth().height(3.dp).background(if (isDarkSidebar) Color.White else accent))
                                    Box(modifier = Modifier.fillMaxWidth(0.7f).height(3.dp).background(Color(0xFF94A3B8)))
                                }
                            }
                            Column(modifier = Modifier.fillMaxSize().padding(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Box(modifier = Modifier.width(56.dp).height(5.dp).background(accent))
                                Box(modifier = Modifier.fillMaxWidth().height(4.dp).background(Color(0xFFCBD5E1)))
                                Box(modifier = Modifier.fillMaxWidth(0.8f).height(4.dp).background(Color(0xFFCBD5E1)))
                                Box(modifier = Modifier.fillMaxWidth(0.6f).height(4.dp).background(secondary))
                            }
                        }
                    }
                } else {
                    Column(modifier = Modifier.fillMaxSize()) {
                        if (spec.layout == TemplateLayout.EXECUTIVE_BANNER) {
                            Box(modifier = Modifier.fillMaxWidth().height(22.dp).background(accent))
                        } else if (spec.layout == TemplateLayout.MODERN_ACCENT_BAR) {
                            Box(modifier = Modifier.fillMaxWidth().height(5.dp).background(accent))
                        }
                        Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Box(modifier = Modifier.width(68.dp).height(6.dp).clip(RoundedCornerShape(3.dp)).background(accent))
                            Box(modifier = Modifier.width(46.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFF94A3B8)))
                            Spacer(modifier = Modifier.height(2.dp))
                            Box(modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(3.dp)).background(secondary))
                            Box(modifier = Modifier.fillMaxWidth(0.85f).height(4.dp).background(Color(0xFFCBD5E1)))
                        }
                    }
                }
            }
            Text(spec.name, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (spec.layout.isTwoColumn) "2-Column" else "1-Column",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF64748B)
                )
                Surface(color = if (unlocked) secondary else Color(0xFFF1F5F9), shape = RoundedCornerShape(6.dp)) {
                    Text(
                        text = when {
                            selected -> "✓ Active"
                            unlocked -> "FREE"
                            else -> "🔒 Sign Up"
                        },
                        color = if (unlocked) accent else Color(0xFF64748B),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}


@Composable
private fun SectionBanner(title: String, bg: Color, accent: Color, font: FontFamily) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(bg)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(text = title, color = accent, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, fontFamily = font)
    }
}
